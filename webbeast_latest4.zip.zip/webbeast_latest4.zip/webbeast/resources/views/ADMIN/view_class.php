<?php
session_start();
error_reporting(0);
include("/xampp/htdocs/webbeast/public/include/database-connection.php");
include('include/checklogin.php');
check_login();

$vid = intval($_GET['id']);

if (isset($_GET['del'])) {
	mysqli_query($conn, "DELETE FROM class_list WHERE id = $vid");
	$_SESSION['msg'] = "Data Deleted !!";
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
	<title>Admin | Extra Academic</title>
	<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="/public/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="/public/vendor/fontawesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="/public/vendor/themify-icons/themify-icons.min.css">
	<link href="/public/vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/select2/select2.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="../ADMIN/include/assets/css/styles.css">
	<link rel="stylesheet" href="../ADMIN/include/assets/css/plugins.css">
	<link rel="stylesheet" href="../ADMIN/include/assets/css/themes/theme-1.css" id="skin_color" />
	<style>
		#class-img {
			max-width: 100%;
			max-height: 35em;
			object-fit: scale-down;
			object-position: center center;
		}
		table{
			background-color: white;
		}
	</style>
</head>

<body>
	<div id="app">
		<?php include('include/sidebar.php'); ?>
		<div class="app-content">
			<?php include('include/header.php'); ?>
			<!-- end: TOP NAVBAR -->
			<div class="main-content">
				<div class="wrap-content container" id="container">
					<!-- start: PAGE TITLE -->
					<section id="page-title">
						<div class="row">
							<div class="col-sm-8">
								<h1 class="mainTitle">Admin | Extra Academic</h1>
							</div>
							<br>
							<?php include('include/clock.php'); ?>
							<ol class="breadcrumb">
								<li>
									<span>Admin</span>
								</li>
								<li class="active">
									<span>Extra Academic</span>
								</li>
							</ol>
						</div>
					</section>
					<!-- end: PAGE TITLE -->
					<!-- start: BASIC EXAMPLE -->
					<div class="content py-5 px-3 bg-gradient-primary">
						<h2><b>Class Details</b></h2>
					</div>
					<div class="row mt-lg-n4 mt-md-n4 justify-content-center">
						<div class="col-lg-10 col-md-10 col-sm-12 col-xs-12">
							<div class="card rounded-0">
								<div class="card-body">
									<div class="container-fluid">
										<?php
										$ret = mysqli_query($conn, "select * from class_list where id='$vid'");
										while ($row = mysqli_fetch_array($ret)) {
										?>

											<table class="table table-bordered">
												<thead>
													<tr>
														<th>Name</th>
														<th>Description</th>
														<th>Fee</th>
														<th>Status</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td><?php echo $row['name']; ?></td>
														<td><?php echo $row['description'];
															str_replace(["\n\r", "\n", "\r"], "<br>", htmlspecialchars_decode($description)) ?></td>
														<td><?php echo $row['fee']; ?></td>
														<td>
															<?php if ($status = "1") :
																echo "Active"; ?>
															<?php elseif ($status = "0") :
																echo "Inactive"; ?>
															<?php endif; ?>
														</td>
														<td>
															<?php
															$pdf = $row['file'];
															$path = $row['image_path'];
															$name = $row['name'];
															?>
															<img src="<?php echo $path . $pdf; ?>" class="img-thumbnail" >
														</td>
													</tr>
												</tbody>
											</table>
											<div class="card-footer py-1 text-center">
												<a class="btn btn-danger btn-sm bg-gradient-danger rounded-0" type="button" href="class_index.php?id=<?php echo $row['id'] ?>&del=delete" onClick="return confirm('Are you sure you want to delete?')"><i class="fa fa-trash"></i> Delete</a>
												<a class="btn btn-primary btn-sm bg-gradient-primary rounded-0" href="manage_class.php?id=<?php echo $row['id'] ?>"><i class="fa fa-edit"></i> Edit</a>
												<a class="btn btn-light btn-sm bg-gradient-light border rounded-0 text-dark" href="class_index.php"><i class="fa fa-angle-left"></i> Back to List</a>
											</div>
										<?php } ?>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- end: BASIC EXAMPLE -->
			<!-- end: SELECT BOXES -->
		</div>
		<!-- start: FOOTER -->
		<?php include('include/footer.php'); ?>
		<!-- end: FOOTER -->

		<!-- start: SETTINGS -->
		<?php include('include/setting.php'); ?>
		<!-- end: SETTINGS -->
	</div>
	<script>
		$(function() {
			$('#delete_data').click(function() {
				_conf("Are you sure to delete this class permanently?", "delete_class", ["<?= isset($id) ? $id : '' ?>"])
			})
		})

		function delete_class($id) {
			start_loader();
			$.ajax({
				url: _base_url_ + "classes/Master.php?f=delete_class",
				method: "POST",
				data: {
					id: $id
				},
				dataType: "json",
				error: err => {
					console.log(err)
					alert_toast("An error occured.", 'error');
					end_loader();
				},
				success: function(resp) {
					if (typeof resp == 'object' && resp.status == 'success') {
						location.replace("./?page=classes");
					} else {
						alert_toast("An error occured.", 'error');
						end_loader();
					}
				}
			})
		}
	</script>
	<!-- start: MAIN JAVASCRIPTS -->
	<script src="/public/vendor/jquery/jquery.min.js"></script>
	<script src="/public/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="/public/vendor/modernizr/modernizr.js"></script>
	<script src="/public/vendor/jquery-cookie/jquery.cookie.js"></script>
	<script src="/public/vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
	<script src="/public/vendor/switchery/switchery.min.js"></script>
	<!-- end: MAIN JAVASCRIPTS -->
	<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
	<script src="/public/vendor/maskedinput/jquery.maskedinput.min.js"></script>
	<script src="/public/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
	<script src="/public/vendor/autosize/autosize.min.js"></script>
	<script src="/public/vendor/selectFx/classie.js"></script>
	<script src="/public/vendor/selectFx/selectFx.js"></script>
	<script src="/public/vendor/select2/select2.min.js"></script>
	<script src="/public/vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
	<script src="/public/vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
	<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
	<!-- start: CLIP-TWO JAVASCRIPTS -->
    <script src="../ADMIN/include/assets/js/main.js"></script>
    <!-- start: JavaScript Event Handlers for this page -->
    <script src="../ADMIN/include/assets/js/form-elements.js"></script>
	<script>
		jQuery(document).ready(function() {
			Main.init();
			FormElements.init();
		});
	</script>
</body>

</html>