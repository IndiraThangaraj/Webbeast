<?php
session_start();
error_reporting(0);
include("/xampp/htdocs/webbeast/public/include/database-connection.php");
include('include/checklogin.php');
check_login();

$status = $statusMsg = '';
if (isset($_POST["upload1"])) {
    $name = $_POST['name'];
    $form = $_POST['form'];
    $subject = $_POST['sub'];
    $status = 'error';
    if (!empty($_FILES["file"]["name"])) {
        // Get file info 
        $fileName = basename($_FILES["file"]["name"]);
        $fileType = pathinfo($fileName, PATHINFO_EXTENSION);
        $file = $_FILES['file']['tmp_name'];
        // Move the uploaded pdf file into the pdf folder
        move_uploaded_file($file, "./pdf/" . $fileName);
        // Allow certain file formats 
        $allowTypes = array('zip', 'pdf', 'rar', 'ZIP');
        if (in_array($fileType, $allowTypes)) {
            // Insert image content into database 
            $sql2 = mysqli_query($conn, "INSERT into tutorhubSTD (file,name,dir,form_std,subject) values ('$fileName','$name','pdf/','$form','$subject')");
            
            if ($sql2) {
                $status = 'success';
                $statusMsg = "File uploaded successfully.";
            } else {
                $statusMsg = "File upload failed, please try again.";
            }
        } else {
            $statusMsg = 'Sorry, only ZIP, RAR & PDF files are allowed to upload.';
        }
    } else {
        $statusMsg = 'Please select a zip file to upload.';
    }
    // Display status message  
    echo $statusMsg;
    echo "<script>window.location.href ='TutorHubStd.php'</script>";
}

if (isset($_GET['del'])) {
    mysqli_query($conn, "DELETE FROM tutorhubstd WHERE id = '" . $_GET['id'] . "'");
    $statusMsg = 'Data Deleted !!';
    echo $statusMsg;
    echo "<script>window.location.href ='TutorHubStd.php'</script>";
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <title>Admin | TutorHubSTD</title>

    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="/public/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="/public/vendor/fontawesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="/public/vendor/themify-icons/themify-icons.min.css">
	<link href="/public/vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/select2/select2.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="../ADMIN/include/assets/css/styles.css">
	<link rel="stylesheet" href="../ADMIN/include/assets/css/plugins.css">
	<link rel="stylesheet" href="../ADMIN/include/assets/css/themes/theme-1.css" id="skin_color" />


    <style>
        th,
        td {
            padding: 10px;
            text-align: left;
        }
    </style>
</head>


<body>
    <div id="app">
        <?php include('include/sidebar.php'); ?>
        <div class="app-content">
            <?php include('include/header.php'); ?>
            <!-- end: TOP NAVBAR -->
            <div class="main-content">
                <div class="wrap-content container" id="container">
                    <!-- start: PAGE TITLE -->
                    <section id="page-title">
                        <div class="row">
                            <div class="col-sm-8">
                                <h1 class="mainTitle">Admin | TutorHub STD</h1>
                            </div>
                            <br>
                            <?php include('include/clock.php'); ?>
                            <ol class="breadcrumb">
                                <li>
                                    <span>Admin</span>
                                </li>
                                <li class="active">
                                    <span>TutorHub STD</span>
                                </li>
                            </ol>
                        </div>
                    </section>
                    <!-- end: PAGE TITLE -->
                    <!-- start: BASIC EXAMPLE -->
                    <div class="container-fluid container-fullw bg-white">
                        <div class="row">
                            <div class="col-md-12">
                                <h5 class="over-title margin-bottom-15">TutorHub STD</h5>
                                <table class="table table-hover" id="sample-table-1">
                                    <thead>
                                        <tr>
                                            <th>Select File: </th>
                                            <th>File Name: </th>
                                            <th>Form/Standard: </th>
                                            <th>Subject: </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <form role="form" class="form" name="edit" method="post" enctype="multipart/form-data">
                                            <tr>
                                                <td>
                                                    <input type="file" name="file">
                                                </td>
                                                <td>
                                                    <input type="text" name="name" placeholder="Name">
                                                </td>
                                                <td>
                                                    <select name="form" class="form-control" required="required">
                                                        <option value="">Select Form/Standard</option>
                                                        <?php $ret = mysqli_query($conn, "select * from form_std");
                                                        while ($row = mysqli_fetch_array($ret)) {
                                                        ?>
                                                            <option value="<?php echo htmlentities($row['Form_Std']); ?>">
                                                                <?php echo htmlentities($row['Form_Std']); ?>
                                                            </option>
                                                        <?php } ?>
                                                    </select>
                                                </td>
                                                <td>
                                                    <select name="sub" class="form-control" required="required">
                                                        <option value="">Select Subject</option>
                                                        <?php $ret = mysqli_query($conn, "select * from subject");
                                                        while ($row = mysqli_fetch_array($ret)) {
                                                        ?>
                                                            <option value="<?php echo htmlentities($row['subject']); ?>">
                                                                <?php echo htmlentities($row['subject']); ?>
                                                            </option>
                                                        <?php } ?>
                                                    </select>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <input type="submit" name="upload1" value="Upload Std 1-6">
                                                </td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                        </form>
                                    </tbody>
                                </table>
                                </br>
                                <table class="table table-hover" id="sample-table-1">
                                    <thead>
                                        <tr>
                                            <th class="center">#</th>
                                            <th>Subject</th>
                                            <th>File Name</th>
                                            <th>File</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $sql = mysqli_query($conn, "SELECT * FROM tutorhubstd");
                                        while ($row = $sql->fetch_object()) {
                                        ?>
                                            <tr>
                                                <td>1.</td>
                                                <td>
                                                    <span>BAHASA MELAYU STD 1-6 </span>
                                                </td>
                                                <td>
                                                    <div class="d-flex1 flex-column align-items-center text-center p-3 py-5">
                                                        <?php
                                                        $sql = mysqli_query($conn, "SELECT * FROM tutorhubstd WHERE subject='Bahasa Melayu'");
                                                        $sql2 = mysqli_query($conn, "select * from tutorhubstd where subject='Bahasa Melayu'");
                                                        while ($row = $sql->fetch_object()) {
                                                            $row1 = mysqli_fetch_array($sql2);
                                                            $pdf = $row->file;
                                                            $path = $row->dir;
                                                            $name = $row->name;

                                                            echo '<strong> File Name: </strong>' . $name; ?><a href="TutorHubStd.php?id=<?php echo $row1['id'] ?>&del=delete" onClick="return confirm('Are you sure you want to delete <?php echo $name ?> ?')" class="btn btn-transparent btn-xs tooltips" tooltip-placement="top" tooltip="Remove">
                                                                <i class="fa fa-times fa fa-white"></i>
                                                            </a>
                                                        <?php echo '</br>';
                                                        } ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <br /><br />
                                                    <?php
                                                    $sql = mysqli_query($conn, "SELECT * FROM tutorhubstd WHERE subject='Bahasa Melayu'");
                                                    while ($row = $sql->fetch_object()) {
                                                        $pdf = $row->file;
                                                        $path = $row->dir;
                                                        $name = $row->name;
                                                    ?>
                                                        <iframe src="<?php echo $path . $pdf; ?>" width="250px" height="250px">
                                                        </iframe>
                                                    <?php } ?>
                                                </td>

                                            </tr>
                                            <tr>
                                                <td>2.</td>
                                                <td><span>ENGLISH STD 1-6 </span></td>
                                                <td>
                                                    <div class="d-flex1 flex-column align-items-center text-center p-3 py-5">
                                                        <?php
                                                        $sql = mysqli_query($conn, "SELECT * FROM tutorhubstd WHERE subject='English'");
                                                        $sql2 = mysqli_query($conn, "select * from tutorhubstd where subject='English'");
                                                        while ($row = $sql->fetch_object()) {
                                                            $row1 = mysqli_fetch_array($sql2);
                                                            $pdf = $row->file;
                                                            $path = $row->dir;
                                                            $name = $row->name;

                                                            echo '<strong> File Name: </strong>' . $name; ?><a href="TutorHubStd.php?id=<?php echo $row1['id'] ?>&del=delete" onClick="return confirm('Are you sure you want to delete <?php echo $name ?> ?')" class="btn btn-transparent btn-xs tooltips" tooltip-placement="top" tooltip="Remove">
                                                                <i class="fa fa-times fa fa-white"></i>
                                                            </a>
                                                        <?php echo '</br>';
                                                        } ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <br /><br />
                                                    <?php
                                                    $sql = mysqli_query($conn, "SELECT * FROM tutorhubstd WHERE subject='English'");
                                                    while ($row = $sql->fetch_object()) {
                                                        $pdf = $row->file;
                                                        $path = $row->dir;
                                                        $name = $row->name;
                                                    ?>
                                                        <iframe src="<?php echo $path . $pdf; ?>" width="250px" height="250px">
                                                        </iframe>
                                                    <?php } ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>3.</td>
                                                <td><span>MATHEMATICS STD 1-6 </span></td>
                                                <td>
                                                    <div class="d-flex1 flex-column align-items-center text-center p-3 py-5">
                                                        <?php
                                                        $sql = mysqli_query($conn, "SELECT * FROM tutorhubstd WHERE subject='Mathematics'");
                                                        $sql2 = mysqli_query($conn, "select * from tutorhubstd where subject='Mathematics'");
                                                        while ($row = $sql->fetch_object()) {
                                                            $row1 = mysqli_fetch_array($sql2);
                                                            $pdf = $row->file;
                                                            $path = $row->dir;
                                                            $name = $row->name;

                                                            echo '<strong> File Name: </strong>' . $name; ?><a href="TutorHubStd.php?id=<?php echo $row1['id'] ?>&del=delete" onClick="return confirm('Are you sure you want to delete <?php echo $name ?> ?')" class="btn btn-transparent btn-xs tooltips" tooltip-placement="top" tooltip="Remove">
                                                                <i class="fa fa-times fa fa-white"></i>
                                                            </a>
                                                        <?php echo '</br>';
                                                        } ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <br /><br />
                                                    <?php
                                                    $sql = mysqli_query($conn, "SELECT * FROM tutorhubstd WHERE subject='Mathematics'");
                                                    while ($row = $sql->fetch_object()) {
                                                        $pdf = $row->file;
                                                        $path = $row->dir;
                                                        $name = $row->name;
                                                    ?>
                                                        <iframe src="<?php echo $path . $pdf; ?>" width="250px" height="250px">
                                                        </iframe>
                                                    <?php } ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>4.</td>
                                                <td><span>SCIENCE STD 1-6 </span></td>
                                                <td>
                                                    <div class="d-flex1 flex-column align-items-center text-center p-3 py-5">
                                                        <?php
                                                        $sql = mysqli_query($conn, "SELECT * FROM tutorhubstd WHERE subject='Science'");
                                                        $sql2 = mysqli_query($conn, "select * from tutorhubstd where subject='Science'");
                                                        while ($row = $sql->fetch_object()) {
                                                            $row1 = mysqli_fetch_array($sql2);
                                                            $pdf = $row->file;
                                                            $path = $row->dir;
                                                            $name = $row->name;

                                                            echo '<strong> File Name: </strong>' . $name; ?><a href="TutorHubStd.php?id=<?php echo $row1['id'] ?>&del=delete" onClick="return confirm('Are you sure you want to delete <?php echo $name ?> ?')" class="btn btn-transparent btn-xs tooltips" tooltip-placement="top" tooltip="Remove">
                                                                <i class="fa fa-times fa fa-white"></i>
                                                            </a>
                                                        <?php echo '</br>';
                                                        } ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <br /><br />
                                                    <?php
                                                    $sql = mysqli_query($conn, "SELECT * FROM tutorhubstd WHERE subject='Science'");
                                                    while ($row = $sql->fetch_object()) {
                                                        $pdf = $row->file;
                                                        $path = $row->dir;
                                                        $name = $row->name;
                                                    ?>
                                                        <iframe src="<?php echo $path . $pdf; ?>" width="250px" height="250px">
                                                        </iframe>
                                                    <?php } ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>5.</td>
                                                <td><span>MORAL STD 1-6 </span></td>
                                                <td>
                                                    <div class="d-flex1 flex-column align-items-center text-center p-3 py-5">
                                                        <?php
                                                        $sql = mysqli_query($conn, "SELECT * FROM tutorhubstd WHERE subject='Pendidikan Moral'");
                                                        $sql2 = mysqli_query($conn, "select * from tutorhubstd where subject='Pendidikan Moral'");
                                                        while ($row = $sql->fetch_object()) {
                                                            $row1 = mysqli_fetch_array($sql2);
                                                            $pdf = $row->file;
                                                            $path = $row->dir;
                                                            $name = $row->name;

                                                            echo '<strong> File Name: </strong>' . $name; ?><a href="TutorHubStd.php?id=<?php echo $row1['id'] ?>&del=delete" onClick="return confirm('Are you sure you want to delete <?php echo $name ?> ?')" class="btn btn-transparent btn-xs tooltips" tooltip-placement="top" tooltip="Remove">
                                                                <i class="fa fa-times fa fa-white"></i>
                                                            </a>
                                                        <?php echo '</br>';
                                                        } ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <br /><br />
                                                    <?php
                                                    $sql = mysqli_query($conn, "SELECT * FROM tutorhubstd WHERE subject='Pendidikan Moral'");
                                                    while ($row = $sql->fetch_object()) {
                                                        $pdf = $row->file;
                                                        $path = $row->dir;
                                                        $name = $row->name;
                                                    ?>
                                                        <iframe src="<?php echo $path . $pdf; ?>" width="250px" height="250px">
                                                        </iframe>
                                                    <?php } ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>6.</td>
                                                <td><span>HISTORY STD 1-6 </span></td>
                                                <td>
                                                    <div class="d-flex1 flex-column align-items-center text-center p-3 py-5">
                                                        <?php
                                                        $sql = mysqli_query($conn, "SELECT * FROM tutorhubstd WHERE subject='History'");
                                                        $sql2 = mysqli_query($conn, "select * from tutorhubstd where subject='History'");
                                                        while ($row = $sql->fetch_object()) {
                                                            $row1 = mysqli_fetch_array($sql2);
                                                            $pdf = $row->file;
                                                            $path = $row->dir;
                                                            $name = $row->name;

                                                            echo '<strong> File Name: </strong>' . $name; ?><a href="TutorHubStd.php?id=<?php echo $row1['id'] ?>&del=delete" onClick="return confirm('Are you sure you want to delete <?php echo $name ?> ?')" class="btn btn-transparent btn-xs tooltips" tooltip-placement="top" tooltip="Remove">
                                                                <i class="fa fa-times fa fa-white"></i>
                                                            </a>
                                                        <?php echo '</br>';
                                                        } ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <br /><br />
                                                    <?php
                                                    $sql = mysqli_query($conn, "SELECT * FROM tutorhubstd WHERE subject='History'");
                                                    while ($row = $sql->fetch_object()) {
                                                        $pdf = $row->file;
                                                        $path = $row->dir;
                                                        $name = $row->name;
                                                    ?>
                                                        <iframe src="<?php echo $path . $pdf; ?>" width="250px" height="250px">
                                                        </iframe>
                                                    <?php } ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>7.</td>
                                                <td><span>PENDIDIKAN SENI STD 1-6 </span></td>
                                                <td>
                                                    <div class="d-flex1 flex-column align-items-center text-center p-3 py-5">
                                                        <?php
                                                        $sql = mysqli_query($conn, "SELECT * FROM tutorhubstd WHERE subject='Pendidikan Seni Visual'");
                                                        $sql2 = mysqli_query($conn, "select * from tutorhubstd where subject='Pendidikan Seni Visual'");
                                                        while ($row = $sql->fetch_object()) {
                                                            $row1 = mysqli_fetch_array($sql2);
                                                            $pdf = $row->file;
                                                            $path = $row->dir;
                                                            $name = $row->name;

                                                            echo '<strong> File Name: </strong>' . $name; ?><a href="TutorHubStd.php?id=<?php echo $row1['id'] ?>&del=delete" onClick="return confirm('Are you sure you want to delete <?php echo $name ?> ?')" class="btn btn-transparent btn-xs tooltips" tooltip-placement="top" tooltip="Remove">
                                                                <i class="fa fa-times fa fa-white"></i>
                                                            </a>
                                                        <?php echo '</br>';
                                                        } ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <br /><br />
                                                    <?php
                                                    $sql = mysqli_query($conn, "SELECT * FROM tutorhubstd WHERE subject='Pendidikan Seni Visual'");
                                                    while ($row = $sql->fetch_object()) {
                                                        $pdf = $row->file;
                                                        $path = $row->dir;
                                                        $name = $row->name;
                                                    ?>
                                                        <iframe src="<?php echo $path . $pdf; ?>" width="250px" height="250px">
                                                        </iframe>
                                                    <?php } ?>
                                                </td>
                                            </tr>
                                        <?php
                                        } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end: BASIC EXAMPLE -->
            <!-- end: SELECT BOXES -->

        </div>
        <!-- start: FOOTER -->
        <?php include('include/footer.php'); ?>
        <!-- end: FOOTER -->

        <!-- start: SETTINGS -->
        <?php include('include/setting.php'); ?>

        <!-- end: SETTINGS -->
    </div>
    <!-- start: MAIN JAVASCRIPTS -->
	<script src="/public/vendor/jquery/jquery.min.js"></script>
	<script src="/public/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="/public/vendor/modernizr/modernizr.js"></script>
	<script src="/public/vendor/jquery-cookie/jquery.cookie.js"></script>
	<script src="/public/vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
	<script src="/public/vendor/switchery/switchery.min.js"></script>
	<!-- end: MAIN JAVASCRIPTS -->
	<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
	<script src="/public/vendor/maskedinput/jquery.maskedinput.min.js"></script>
	<script src="/public/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
	<script src="/public/vendor/autosize/autosize.min.js"></script>
	<script src="/public/vendor/selectFx/classie.js"></script>
	<script src="/public/vendor/selectFx/selectFx.js"></script>
	<script src="/public/vendor/select2/select2.min.js"></script>
	<script src="/public/vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
	<script src="/public/vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
	<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
	<!-- start: CLIP-TWO JAVASCRIPTS -->
    <script src="../ADMIN/include/assets/js/main.js"></script>
    <!-- start: JavaScript Event Handlers for this page -->
    <script src="../ADMIN/include/assets/js/form-elements.js"></script>
    <script>
        jQuery(document).ready(function() {
            Main.init();
            FormElements.init();
        });
    </script>
    <!-- end: JavaScript Event Handlers for this page -->
    <!-- end: CLIP-TWO JAVASCRIPTS -->
</body>

</html>