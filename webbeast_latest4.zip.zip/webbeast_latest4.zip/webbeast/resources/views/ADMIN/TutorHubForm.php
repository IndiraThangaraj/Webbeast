<?php
session_start();
error_reporting(0);
include("/xampp/htdocs/webbeast/public/include/database-connection.php");
include('include/checklogin.php');
check_login();

$status = $statusMsg = '';
if (isset($_POST["upload1"])) {
    $name = $_POST['name'];
    $form = $_POST['form'];
    $subject = $_POST['sub'];
    $status = 'error';

    if (!empty($_FILES["file"]["name"])) {
        // Get file info 
        $fileName = basename($_FILES["file"]["name"]);
        $fileType = pathinfo($fileName, PATHINFO_EXTENSION);
        $file = $_FILES['file']['tmp_name'];
        // Move the uploaded pdf file into the pdf folder
        move_uploaded_file($file, "/xampp/htdocs/webbeast/resources/views/ADMIN/pdf/" . $fileName);
        
        // Allow certain file formats 
        $allowTypes = array('zip', 'pdf', 'rar', 'ZIP');
        if (in_array($fileType, $allowTypes)) {
            // Insert image content into database 
            $sql2 = mysqli_query($conn, "INSERT into tutorhubform (file,name,dir,form_std,subject) values ('$fileName','$name','pdf/','$form','$subject')");

            if ($sql2) {
                $status = 'success';
                $statusMsg = "File uploaded successfully.";
            } else {
                $statusMsg = "File upload failed, please try again.";
            }
        } else {
            $statusMsg = 'Sorry, only ZIP, RAR & PDF files are allowed to upload.';
        }
    } else {
        $statusMsg = 'Please select a zip file to upload.';
    }
    // Display status message  
    echo $statusMsg;
    echo "<script>window.location.href ='TutorHubForm.php'</script>";
}
if (isset($_GET['del'])) {
    mysqli_query($conn, "DELETE FROM tutorhubform WHERE id = '" . $_GET['id'] . "'");
    $statusMsg = 'Data Deleted !!';
    echo $statusMsg;
    echo "<script>window.location.href ='TutorHubForm.php'</script>";
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <title>Admin | TutorHubForm</title>

    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="/public/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="/public/vendor/fontawesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="/public/vendor/themify-icons/themify-icons.min.css">
	<link href="/public/vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/select2/select2.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="../ADMIN/include/assets/css/styles.css">
	<link rel="stylesheet" href="../ADMIN/include/assets/css/plugins.css">
	<link rel="stylesheet" href="../ADMIN/include/assets/css/themes/theme-1.css" id="skin_color" />

</head>


<body>
    <div id="app">
        <?php include('include/sidebar.php'); ?>
        <div class="app-content">
            <?php include('include/header.php'); ?>
            <!-- end: TOP NAVBAR -->
            <div class="main-content">
                <div class="wrap-content container" id="container">
                    <!-- start: PAGE TITLE -->
                    <section id="page-title">
                        <div class="row">
                            <div class="col-sm-8">
                                <h1 class="mainTitle">Admin | TutorHub FORM</h1>
                            </div>
                            <br>
                            <?php include('include/clock.php'); ?>
                            <ol class="breadcrumb">
                                <li>
                                    <span>Admin</span>
                                </li>
                                <li class="active">
                                    <span>TutorHub FORM</span>
                                </li>
                            </ol>
                        </div>
                    </section>
                    <!-- end: PAGE TITLE -->
                    <!-- start: BASIC EXAMPLE -->
                    <div class="container-fluid container-fullw bg-white">
                        <div class="row">
                            <div class="col-md-12">
                                <h5 class="over-title margin-bottom-15">TutorHub FORM</h5>
                                <table class="table table-hover" id="sample-table-1">
                                    <thead>
                                        <tr>
                                            <th>Select File: </th>
                                            <th>File Name: </th>
                                            <th>Form/Standard: </th>
                                            <th>Subject: </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <form role="form" class="form" name="edit" method="post" enctype="multipart/form-data">
                                            <tr>
                                                <td>
                                                    <input type="file" name="file">
                                                </td>
                                                <td>
                                                    <input type="text" name="name" placeholder="Name">
                                                </td>
                                                <td>
                                                    <select name="form" class="form-control" required="required">
                                                        <option value="">Select Form/Standard</option>
                                                        <?php $ret = mysqli_query($conn, "select * from form_std");
                                                        while ($row = mysqli_fetch_array($ret)) {
                                                        ?>
                                                            <option value="<?php echo htmlentities($row['Form_Std']); ?>">
                                                                <?php echo htmlentities($row['Form_Std']); ?>
                                                            </option>
                                                        <?php } ?>
                                                    </select>
                                                </td>
                                                <td>
                                                    <select name="sub" class="form-control" required="required">
                                                        <option value="">Select Subject</option>
                                                        <?php $ret = mysqli_query($conn, "select * from subject");
                                                        while ($row = mysqli_fetch_array($ret)) {
                                                        ?>
                                                            <option value="<?php echo htmlentities($row['subject']); ?>">
                                                                <?php echo htmlentities($row['subject']); ?>
                                                            </option>
                                                        <?php } ?>
                                                    </select>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <input type="submit" name="upload1" value="Upload Form 1-5">
                                                </td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                        </form>
                                    </tbody>
                                </table>
                                </br>
                                <table class="table table-hover" id="sample-table-1">
                                    <thead>
                                        <tr>
                                            <th class="center">#</th>
                                            <th>Subject</th>
                                            <th>File Name</th>
                                            <th>File</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $sql = mysqli_query($conn, "SELECT * FROM tutorhubform");
                                        while ($row = $sql->fetch_object()) {
                                        ?>
                                            <tr>
                                                <td>1.</td>
                                                <td><span>BAHASA MELAYU FORM 1-5 </span></td>
                                                <td>
                                                    <div class="d-flex1 flex-column align-items-center text-center p-3 py-5">
                                                        <?php
                                                        $sql = mysqli_query($conn, "SELECT * FROM tutorhubform WHERE subject='Bahasa Melayu'");
                                                        $sql2 = mysqli_query($conn, "select * from tutorhubform where subject='Bahasa Melayu'");
                                                            while ($row = $sql->fetch_object()) {
                                                                $row1 = mysqli_fetch_array($sql2);
                                                                $pdf = $row->file;
                                                                $path = $row->dir;
                                                                $name = $row->name;
                                                                $id = $row->id;
                                                                echo '<strong> File Name: </strong>' . $name; ?><a href="TutorHubForm.php?id=<?php echo $row1['id'] ?>&del=delete" onClick="return confirm('Are you sure you want to delete <?php echo $name ?> ?')" class="btn btn-transparent btn-xs tooltips" tooltip-placement="top" tooltip="Remove">
                                                                <i class="fa fa-times fa fa-white"></i>
                                                            </a>
                                                               <?php echo '</br>';
                                                            } ?>
                                                            

                                                    </div>
                                                </td>
                                                <td>
                                                    <br /><br />
                                                    <?php
                                                    $sql = mysqli_query($conn, "SELECT * FROM tutorhubform WHERE subject='Bahasa Melayu'");
                                                    while ($row = $sql->fetch_object()) {
                                                        $pdf = $row->file;
                                                        $path = $row->dir;
                                                        $name = $row->name;
                                                    ?>
                                                        <iframe src="<?php echo $path . $pdf; ?>" width="250px" height="250px">
                                                        </iframe>
                                                    <?php } ?>
                                                </td>
                                                <td>

                                                </td>
                                            </tr>
                                            <tr>
                                                <td>2.</td>
                                                <td><span>ENGLISH FORM 1-5 </span></td>
                                                <td>
                                                    <div class="d-flex1 flex-column align-items-center text-center p-3 py-5">
                                                        <?php
                                                        $sql = mysqli_query($conn, "SELECT * FROM tutorhubform WHERE subject='English'");
                                                        $sql2 = mysqli_query($conn, "select * from tutorhubform where subject='English'");
                                                        while ($row = $sql->fetch_object()) {
                                                            $row1 = mysqli_fetch_array($sql2);
                                                            $pdf = $row->file;
                                                            $path = $row->dir;
                                                            $name = $row->name;

                                                            echo '<strong> File Name: </strong>' . $name;?><a href="TutorHubForm.php?id=<?php echo $row1['id'] ?>&del=delete" onClick="return confirm('Are you sure you want to delete <?php echo $name ?> ?')" class="btn btn-transparent btn-xs tooltips" tooltip-placement="top" tooltip="Remove">
                                                            <i class="fa fa-times fa fa-white"></i>
                                                        </a>
                                                           <?php echo '</br>';
                                                        } ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <br /><br />
                                                    <?php
                                                    $sql = mysqli_query($conn, "SELECT * FROM tutorhubform WHERE subject='English'");
                                                    while ($row = $sql->fetch_object()) {
                                                        $pdf = $row->file;
                                                        $path = $row->dir;
                                                        $name = $row->name;
                                                    ?>
                                                        <iframe src="<?php echo $path . $pdf; ?>" width="250px" height="250px">
                                                        </iframe>
                                                    <?php } ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>3.</td>
                                                <td><span>MATHEMATICS FORM 1-5 </span></td>
                                                <td>
                                                    <div class="d-flex1 flex-column align-items-center text-center p-3 py-5">
                                                        <?php
                                                        $sql = mysqli_query($conn, "SELECT * FROM tutorhubform WHERE subject='Mathematics'");
                                                        $sql2 = mysqli_query($conn, "select * from tutorhubform where subject='Mathematics'");
                                                        
                                                        while ($row = $sql->fetch_object()) {
                                                            $row1 = mysqli_fetch_array($sql2);
                                                            $pdf = $row->file;
                                                            $path = $row->dir;
                                                            $name = $row->name;

                                                            echo '<strong> File Name: </strong>' . $name;?><a href="TutorHubForm.php?id=<?php echo $row1['id'] ?>&del=delete" onClick="return confirm('Are you sure you want to delete <?php echo $name ?> ?')" class="btn btn-transparent btn-xs tooltips" tooltip-placement="top" tooltip="Remove">
                                                            <i class="fa fa-times fa fa-white"></i>
                                                        </a>
                                                           <?php echo '</br>';
                                                        } ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <br /><br />
                                                    <?php
                                                    $sql = mysqli_query($conn, "SELECT * FROM tutorhubform WHERE subject='Mathematics'");
                                                    while ($row = $sql->fetch_object()) {
                                                        $pdf = $row->file;
                                                        $path = $row->dir;
                                                        $name = $row->name;
                                                    ?>
                                                        <iframe src="<?php echo $path . $pdf; ?>" width="250px" height="250px">
                                                        </iframe>
                                                    <?php } ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>4.</td>
                                                <td><span>SCIENCE FORM 1-5 </span></td>
                                                <td>
                                                    <div class="d-flex1 flex-column align-items-center text-center p-3 py-5">
                                                        <?php
                                                        $sql = mysqli_query($conn, "SELECT * FROM tutorhubform WHERE subject='Science'");
                                                        $sql2 = mysqli_query($conn, "select * from tutorhubform where subject='Science'");
                                                        while ($row = $sql->fetch_object()) {
                                                            $row1 = mysqli_fetch_array($sql2);
                                                            $pdf = $row->file;
                                                            $path = $row->dir;
                                                            $name = $row->name;

                                                            echo '<strong> File Name: </strong>' . $name;?><a href="TutorHubForm.php?id=<?php echo $row1['id'] ?>&del=delete" onClick="return confirm('Are you sure you want to delete <?php echo $name ?> ?')" class="btn btn-transparent btn-xs tooltips" tooltip-placement="top" tooltip="Remove">
                                                            <i class="fa fa-times fa fa-white"></i>
                                                        </a>
                                                           <?php echo '</br>';
                                                        } ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <br /><br />
                                                    <?php
                                                    $sql = mysqli_query($conn, "SELECT * FROM tutorhubform WHERE subject='Science'");
                                                    while ($row = $sql->fetch_object()) {
                                                        $pdf = $row->file;
                                                        $path = $row->dir;
                                                        $name = $row->name;
                                                    ?>
                                                        <iframe src="<?php echo $path . $pdf; ?>" width="250px" height="250px">
                                                        </iframe>
                                                    <?php } ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>5.</td>
                                                <td><span>MORAL FORM 1-5 </span></td>
                                                <td>
                                                    <div class="d-flex1 flex-column align-items-center text-center p-3 py-5">
                                                        <?php
                                                        $sql = mysqli_query($conn, "SELECT * FROM tutorhubform WHERE subject='Pendidikan Moral'");
                                                        $sql2 = mysqli_query($conn, "select * from tutorhubform where subject='Pendidikan Moral'");
                                                        while ($row = $sql->fetch_object()) {
                                                            $row1 = mysqli_fetch_array($sql2);
                                                            $pdf = $row->file;
                                                            $path = $row->dir;
                                                            $name = $row->name;

                                                            echo '<strong> File Name: </strong>' . $name;?><a href="TutorHubForm.php?id=<?php echo $row1['id'] ?>&del=delete" onClick="return confirm('Are you sure you want to delete <?php echo $name ?> ?')" class="btn btn-transparent btn-xs tooltips" tooltip-placement="top" tooltip="Remove">
                                                            <i class="fa fa-times fa fa-white"></i>
                                                        </a>
                                                           <?php echo '</br>';
                                                        } ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <br /><br />
                                                    <?php
                                                    $sql = mysqli_query($conn, "SELECT * FROM tutorhubform WHERE subject='Pendidikan Moral'");
                                                    while ($row = $sql->fetch_object()) {
                                                        $pdf = $row->file;
                                                        $path = $row->dir;
                                                        $name = $row->name;
                                                    ?>
                                                        <iframe src="<?php echo $path . $pdf; ?>" width="250px" height="250px">
                                                        </iframe>
                                                    <?php } ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>6.</td>
                                                <td><span>HISTORY FORM 1-5 </span></td>
                                                <td>
                                                    <div class="d-flex1 flex-column align-items-center text-center p-3 py-5">
                                                        <?php
                                                        $sql = mysqli_query($conn, "SELECT * FROM tutorhubform WHERE subject='History'");
                                                        $sql2 = mysqli_query($conn, "select * from tutorhubform where subject='History'");
                                                        while ($row = $sql->fetch_object()) {
                                                            $row1 = mysqli_fetch_array($sql2);
                                                            $pdf = $row->file;
                                                            $path = $row->dir;
                                                            $name = $row->name;

                                                            echo '<strong> File Name: </strong>' . $name;?><a href="TutorHubForm.php?id=<?php echo $row1['id'] ?>&del=delete" onClick="return confirm('Are you sure you want to delete <?php echo $name ?> ?')" class="btn btn-transparent btn-xs tooltips" tooltip-placement="top" tooltip="Remove">
                                                            <i class="fa fa-times fa fa-white"></i>
                                                        </a>
                                                           <?php echo '</br>';
                                                        } ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <br /><br />
                                                    <?php
                                                    $sql = mysqli_query($conn, "SELECT * FROM tutorhubform WHERE subject='History'");
                                                    while ($row = $sql->fetch_object()) {
                                                        $pdf = $row->file;
                                                        $path = $row->dir;
                                                        $name = $row->name;
                                                    ?>
                                                        <iframe src="<?php echo $path . $pdf; ?>" width="250px" height="250px">
                                                        </iframe>
                                                    <?php } ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>7.</td>
                                                <td><span>GEOGRAPHY FORM 1-3 </span></td>
                                                <td>
                                                    <div class="d-flex1 flex-column align-items-center text-center p-3 py-5">
                                                        <?php
                                                        $sql = mysqli_query($conn, "SELECT * FROM tutorhubform WHERE subject='Geography'");
                                                        $sql2 = mysqli_query($conn, "select * from tutorhubform where subject='Geography'");
                                                        while ($row = $sql->fetch_object()) {
                                                            $row1 = mysqli_fetch_array($sql2);
                                                            $pdf = $row->file;
                                                            $path = $row->dir;
                                                            $name = $row->name;

                                                            echo '<strong> File Name: </strong>' . $name;?><a href="TutorHubForm.php?id=<?php echo $row1['id'] ?>&del=delete" onClick="return confirm('Are you sure you want to delete <?php echo $name ?> ?')" class="btn btn-transparent btn-xs tooltips" tooltip-placement="top" tooltip="Remove">
                                                            <i class="fa fa-times fa fa-white"></i>
                                                        </a>
                                                           <?php echo '</br>';
                                                        } ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <br /><br />
                                                    <?php
                                                    $sql = mysqli_query($conn, "SELECT * FROM tutorhubform WHERE subject='Geography'");
                                                    while ($row = $sql->fetch_object()) {
                                                        $pdf = $row->file;
                                                        $path = $row->dir;
                                                        $name = $row->name;
                                                    ?>
                                                        <iframe src="<?php echo $path . $pdf; ?>" width="250px" height="250px">
                                                        </iframe>
                                                    <?php } ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>8.</td>
                                                <td><span>PHYSICS FORM 4-5 </span></td>
                                                <td>
                                                    <div class="d-flex1 flex-column align-items-center text-center p-3 py-5">
                                                        <?php
                                                        $sql = mysqli_query($conn, "SELECT * FROM tutorhubform WHERE subject='Physics'");
                                                        $sql2 = mysqli_query($conn, "select * from tutorhubform where subject='Physics'");
                                                        while ($row = $sql->fetch_object()) {
                                                            $row1 = mysqli_fetch_array($sql2);
                                                            $pdf = $row->file;
                                                            $path = $row->dir;
                                                            $name = $row->name;

                                                            echo '<strong> File Name: </strong>' . $name;?><a href="TutorHubForm.php?id=<?php echo $row1['id'] ?>&del=delete" onClick="return confirm('Are you sure you want to delete <?php echo $name ?> ?')" class="btn btn-transparent btn-xs tooltips" tooltip-placement="top" tooltip="Remove">
                                                            <i class="fa fa-times fa fa-white"></i>
                                                        </a>
                                                           <?php echo '</br>';
                                                        } ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <br /><br />
                                                    <?php
                                                    $sql = mysqli_query($conn, "SELECT * FROM tutorhubform WHERE subject='Physics'");
                                                    while ($row = $sql->fetch_object()) {
                                                        $pdf = $row->file;
                                                        $path = $row->dir;
                                                        $name = $row->name;
                                                    ?>
                                                        <iframe src="<?php echo $path . $pdf; ?>" width="250px" height="250px">
                                                        </iframe>
                                                    <?php } ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>9.</td>
                                                <td><span>CHEMISTRY FORM 4-5 </span></td>
                                                <td>
                                                    <div class="d-flex1 flex-column align-items-center text-center p-3 py-5">
                                                        <?php
                                                        $sql = mysqli_query($conn, "SELECT * FROM tutorhubform WHERE subject='Chemistry'");
                                                        $sql2 = mysqli_query($conn, "select * from tutorhubform where subject='Chemistry'");
                                                        while ($row = $sql->fetch_object()) {
                                                            $row1 = mysqli_fetch_array($sql2);
                                                            $pdf = $row->file;
                                                            $path = $row->dir;
                                                            $name = $row->name;

                                                            echo '<strong> File Name: </strong>' . $name;?><a href="TutorHubForm.php?id=<?php echo $row1['id'] ?>&del=delete" onClick="return confirm('Are you sure you want to delete <?php echo $name ?> ?')" class="btn btn-transparent btn-xs tooltips" tooltip-placement="top" tooltip="Remove">
                                                            <i class="fa fa-times fa fa-white"></i>
                                                        </a>
                                                           <?php echo '</br>';
                                                        } ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <br /><br />
                                                    <?php
                                                    $sql = mysqli_query($conn, "SELECT * FROM tutorhubform WHERE subject='Chemistry'");
                                                    while ($row = $sql->fetch_object()) {
                                                        $pdf = $row->file;
                                                        $path = $row->dir;
                                                        $name = $row->name;
                                                    ?>
                                                        <iframe src="<?php echo $path . $pdf; ?>" width="250px" height="250px">
                                                        </iframe>
                                                    <?php } ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>10.</td>
                                                <td><span>BIOLOGY FORM 4-5 </span></td>
                                                <td>
                                                    <div class="d-flex1 flex-column align-items-center text-center p-3 py-5">
                                                        <?php
                                                        $sql = mysqli_query($conn, "SELECT * FROM tutorhubform WHERE subject='Biology'");
                                                        $sql2 = mysqli_query($conn, "select * from tutorhubform where subject='Biology'");
                                                        while ($row = $sql->fetch_object()) {
                                                            $row1 = mysqli_fetch_array($sql2);
                                                            $pdf = $row->file;
                                                            $path = $row->dir;
                                                            $name = $row->name;

                                                            echo '<strong> File Name: </strong>' . $name;?><a href="TutorHubForm.php?id=<?php echo $row1['id'] ?>&del=delete" onClick="return confirm('Are you sure you want to delete <?php echo $name ?> ?')" class="btn btn-transparent btn-xs tooltips" tooltip-placement="top" tooltip="Remove">
                                                            <i class="fa fa-times fa fa-white"></i>
                                                        </a>
                                                           <?php echo '</br>';
                                                        } ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <br /><br />
                                                    <?php
                                                    $sql = mysqli_query($conn, "SELECT * FROM tutorhubform WHERE subject='Biology'");
                                                    while ($row = $sql->fetch_object()) {
                                                        $pdf = $row->file;
                                                        $path = $row->dir;
                                                        $name = $row->name;
                                                    ?>
                                                        <iframe src="<?php echo $path . $pdf; ?>" width="250px" height="250px">
                                                        </iframe>
                                                    <?php } ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>11.</td>
                                                <td><span>ADDMATHS FORM 4-5 </span></td>
                                                <td>
                                                    <div class="d-flex1 flex-column align-items-center text-center p-3 py-5">
                                                        <?php
                                                        $sql = mysqli_query($conn, "SELECT * FROM tutorhubform WHERE subject='Additional Mathematics'");
                                                        $sql2 = mysqli_query($conn, "select * from tutorhubform where subject='Additional Mathematics'");
                                                        while ($row = $sql->fetch_object()) {
                                                            $row1 = mysqli_fetch_array($sql2);
                                                            $pdf = $row->file;
                                                            $path = $row->dir;
                                                            $name = $row->name;

                                                            echo '<strong> File Name: </strong>' . $name;?><a href="TutorHubForm.php?id=<?php echo $row1['id'] ?>&del=delete" onClick="return confirm('Are you sure you want to delete <?php echo $name ?> ?')" class="btn btn-transparent btn-xs tooltips" tooltip-placement="top" tooltip="Remove">
                                                            <i class="fa fa-times fa fa-white"></i>
                                                        </a>
                                                           <?php echo '</br>';
                                                        } ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <br /><br />
                                                    <?php
                                                    $sql = mysqli_query($conn, "SELECT * FROM tutorhubform WHERE subject='Additional Mathematics'");
                                                    while ($row = $sql->fetch_object()) {
                                                        $pdf = $row->file;
                                                        $path = $row->dir;
                                                        $name = $row->name;
                                                    ?>
                                                        <iframe src="<?php echo $path . $pdf; ?>" width="250px" height="250px">
                                                        </iframe>
                                                    <?php } ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>12.</td>
                                                <td><span>ACCOUNTS FORM 4-5 </span></td>
                                                <td>
                                                    <div class="d-flex1 flex-column align-items-center text-center p-3 py-5">
                                                        <?php
                                                        $sql = mysqli_query($conn, "SELECT * FROM tutorhubform WHERE subject='Accounting'");
                                                        $sql2 = mysqli_query($conn, "select * from tutorhubform where subject='Accounting'");
                                                        while ($row = $sql->fetch_object()) {
                                                            $row1 = mysqli_fetch_array($sql2);
                                                            $pdf = $row->file;
                                                            $path = $row->dir;
                                                            $name = $row->name;

                                                            echo '<strong> File Name: </strong>' . $name;?><a href="TutorHubForm.php?id=<?php echo $row1['id'] ?>&del=delete" onClick="return confirm('Are you sure you want to delete <?php echo $name ?> ?')" class="btn btn-transparent btn-xs tooltips" tooltip-placement="top" tooltip="Remove">
                                                            <i class="fa fa-times fa fa-white"></i>
                                                        </a>
                                                           <?php echo '</br>';
                                                        } ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <br /><br />
                                                    <?php
                                                    $sql = mysqli_query($conn, "SELECT * FROM tutorhubform WHERE subject='Accounting'");
                                                    while ($row = $sql->fetch_object()) {
                                                        $pdf = $row->file;
                                                        $path = $row->dir;
                                                        $name = $row->name;
                                                    ?>
                                                        <iframe src="<?php echo $path . $pdf; ?>" width="250px" height="250px">
                                                        </iframe>
                                                    <?php } ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>13.</td>
                                                <td><span>PERNIAGAAN FORM 4-5 </span></td>
                                                <td>
                                                    <div class="d-flex1 flex-column align-items-center text-center p-3 py-5">
                                                        <?php
                                                        $sql = mysqli_query($conn, "SELECT * FROM tutorhubform WHERE subject='Perniagaan'");
                                                        $sql2 = mysqli_query($conn, "select * from tutorhubform where subject='Perniagaan'");
                                                        while ($row = $sql->fetch_object()) {
                                                            $row1 = mysqli_fetch_array($sql2);
                                                            $pdf = $row->file;
                                                            $path = $row->dir;
                                                            $name = $row->name;

                                                            echo '<strong> File Name: </strong>' . $name;?><a href="TutorHubForm.php?id=<?php echo $row1['id'] ?>&del=delete" onClick="return confirm('Are you sure you want to delete <?php echo $name ?> ?')" class="btn btn-transparent btn-xs tooltips" tooltip-placement="top" tooltip="Remove">
                                                            <i class="fa fa-times fa fa-white"></i>
                                                        </a>
                                                           <?php echo '</br>';
                                                        } ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <br /><br />
                                                    <?php
                                                    $sql = mysqli_query($conn, "SELECT * FROM tutorhubform WHERE subject='Perniagaan'");
                                                    while ($row = $sql->fetch_object()) {
                                                        $pdf = $row->file;
                                                        $path = $row->dir;
                                                        $name = $row->name;
                                                    ?>
                                                        <iframe src="<?php echo $path . $pdf; ?>" width="250px" height="250px">
                                                        </iframe>
                                                    <?php } ?>
                                                </td>
                                            </tr>

                                        <?php
                                        } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end: BASIC EXAMPLE -->
            <!-- end: SELECT BOXES -->

        </div>
        <!-- start: FOOTER -->
        <?php include('include/footer.php'); ?>
        <!-- end: FOOTER -->

        <!-- start: SETTINGS -->
        <?php include('include/setting.php'); ?>

        <!-- end: SETTINGS -->
    </div>
    <!-- start: MAIN JAVASCRIPTS -->
	<script src="/public/vendor/jquery/jquery.min.js"></script>
	<script src="/public/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="/public/vendor/modernizr/modernizr.js"></script>
	<script src="/public/vendor/jquery-cookie/jquery.cookie.js"></script>
	<script src="/public/vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
	<script src="/public/vendor/switchery/switchery.min.js"></script>
	<!-- end: MAIN JAVASCRIPTS -->
	<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
	<script src="/public/vendor/maskedinput/jquery.maskedinput.min.js"></script>
	<script src="/public/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
	<script src="/public/vendor/autosize/autosize.min.js"></script>
	<script src="/public/vendor/selectFx/classie.js"></script>
	<script src="/public/vendor/selectFx/selectFx.js"></script>
	<script src="/public/vendor/select2/select2.min.js"></script>
	<script src="/public/vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
	<script src="/public/vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
	<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
	<!-- start: CLIP-TWO JAVASCRIPTS -->
    <script src="../ADMIN/include/assets/js/main.js"></script>
    <!-- start: JavaScript Event Handlers for this page -->
    <script src="../ADMIN/include/assets/js/form-elements.js"></script>
    <script>
        jQuery(document).ready(function() {
            Main.init();
            FormElements.init();
        });
    </script>
    <!-- end: JavaScript Event Handlers for this page -->
    <!-- end: CLIP-TWO JAVASCRIPTS -->
</body>

</html>