<?php
session_start();
error_reporting(0);
include("/xampp/htdocs/webbeast/public/include/database-connection.php");
include('/xampp/htdocs/webbeast/public/include/checklogin.php');
check_login(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>User | Extra Academic</title>
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="/public/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="/public/vendor/fontawesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="/public/vendor/themify-icons/themify-icons.min.css">
	<link href="/public/vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/select2/select2.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
	<link rel="stylesheet" href="../student/include/assets/css/styles.css">
	<link rel="stylesheet" href="../student/include/assets/css/plugins.css">
	<link rel="stylesheet" href="../student/include/assets/css/themes/theme-1.css" id="skin_color" />
	<style>
    .class-img-holder{
        width:100%;
        height:18em;
        overflow:hidden;
    }
    .class-img{
        width:100%;
        height:100%;
        object-fit: cover;
        object-position: center center;
        transition: all .3s ease-in-out;
    }
    .class-item:hover .class-img{
        transform: scale(1.2)
    }
    #search:empty{
        font-style:italic;
    }
    #search{
        border-right:unset !important;
        border-top-right-radius:0px !important;
        border-bottom-right-radius:0px !important;
    }
    #search-icon{
        border-left:unset !important;
        border-top-left-radius:0px !important;
        border-bottom-left-radius:0px !important;
    }
    #search:focus{

    }
</style>
</head>

<body>
	<div id="app">
		<?php include('include/sidebar.php'); ?>
		<div class="app-content">

			<?php include('include/header.php'); ?>
			<?php
			$sql = mysqli_query($conn, "SELECT * from stud where id='" . $_SESSION['id'] . "'");
			while ($data = mysqli_fetch_array($sql)) { ?>

				<!-- end: TOP NAVBAR -->
				<div class="main-content">
					<div class="wrap-content container" id="container">
						<!-- start: PAGE TITLE -->
						<section id="page-title">
							<div class="row">
								<div class="col-sm-8">
									<h1 class="mainTitle"><?php echo htmlentities($data['name']);
															?> | Extra Academic</h1>
								</div>
								<br>
								<?php include('include/clock.php'); ?>
								<ol class="breadcrumb">
									<li>
										<span><?php echo htmlentities($data['name']);
											} ?></span>
									</li>
									<li class="active">
										<span>Extra Academic</span>
									</li>
								</ol>
						</section>
						<!-- end: PAGE TITLE -->
						<!-- start: BASIC EXAMPLE -->
						<div class="container-fluid container-fullw bg-white">
							<div class="row">
								<div class="col-md-12">

									<div class="row margin-top-30">
										<div class="col-lg-8 col-md-12">
											<div class="panel panel-white">
												<div class="panel-heading">
													
												</div>
												<div class="panel-body">
													<p style="color:red;"><?php echo htmlentities($_SESSION['msg1']); ?>
														<?php echo htmlentities($_SESSION['msg1'] = ""); ?></p>

<section class="py-2">
	<div class="container">
		<div class="bg-gradient-primary py-5 px-3">
            <div class="clear-flex my-5"></div>
		</div>
		<div class="row justify-content-center" style="margin-top:-6em">
            <div class="col-lg-10 col-md-11 col-sm-11 col-sm-11">
                <div class="card card-outline rounded-0">
                    <div class="card-body">
			            <h2 class="mt-3 text-center">List of Classes We Offer</h2>
                        <center>
                            <hr class="bg-primary" style="opacity:1;height:2px;width:5em">
                            </center>
                        <br>
                        <div class="row justify-content-center mb-3">
                            <div class="col-lg-8 col-md-10 col-xs-12 col-sm-12">
                                <div class="input-group input-group-lg">
                                    <input type="search" id="search" class="form-control rounded-pill px-3 border-light" placeholder="Find class by name or description">
                                    <span class="btn btn-outline border rounded-pill text-light" id="search-icon" type="button"><i class="fa fa-search"></i></span>
                                </div>
                            </div>
                        </div>
                        <div class="row row-cols-xl-2 row-md-2 col-sm-12 col-xs-12 gy-3 gx-3 align-items-center justify-content-center">
                            <?php 
                                $qry = $conn->query("SELECT * FROM `class_list` where delete_flag = 0 and `status` = 1 order by `name` asc");
                                while($row = $qry->fetch_assoc()):
                            ?>
                           
                            <div class="col class-item">
                                <a class="card rounded-0 shadow class-item text-decoration-none text-reset" href="view_class.php?file_id=<?php echo $row['id'] ?>">
                                    <div class="position-relative">
                                        <div class="img-top position-relative class-img-holder">
                                            <img src="<?= ($row['image_path']) ?>" alt="" class="class-img">
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div style="line-height:1em">
                                            <div class="card-title w-100"><?= $row['name'] ?></div>
                                            <div class="card-description w-100 truncate-3"><small class="text-muted"><?= strip_tags(htmlspecialchars_decode($row['description'])) ?></small></div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    </div>
                </div>
            </div>
		</div>
	</div>
</section>
<script>
    $(function(){
        $('#search').on('input change', function(){
            var _f = $(this).val().toLowerCase()
            $('.class-item').each(function(){
                var txt = $(this).text().toLowerCase()
                if(txt.includes(_f)){
                    $(this).toggle(true)
                }else{
                    $(this).toggle(false)
                }
            })
        })
    })
</script>
</div>
											</div>
										</div>

									</div>
								</div>

							</div>
						</div>

						<!-- end: BASIC EXAMPLE -->






						<!-- end: SELECT BOXES -->

					</div>
				</div>
		</div>
		<!-- start: FOOTER -->
		<?php include('include/footer.php'); ?>
		<!-- end: FOOTER -->

		<!-- start: SETTINGS -->
		<?php include('include/setting.php'); ?>

		<!-- end: SETTINGS -->
	</div>
	<!-- start: MAIN JAVASCRIPTS -->
	<script src="/public/vendor/jquery/jquery.min.js"></script>
	<script src="/public/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="/public/vendor/modernizr/modernizr.js"></script>
	<script src="/public/vendor/jquery-cookie/jquery.cookie.js"></script>
	<script src="/public/vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
	<script src="/public/vendor/switchery/switchery.min.js"></script>
	<!-- end: MAIN JAVASCRIPTS -->
	<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
	<script src="/public/vendor/maskedinput/jquery.maskedinput.min.js"></script>
	<script src="/public/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
	<script src="/public/vendor/autosize/autosize.min.js"></script>
	<script src="/public/vendor/selectFx/classie.js"></script>
	<script src="/public/vendor/selectFx/selectFx.js"></script>
	<script src="/public/vendor/select2/select2.min.js"></script>
	<script src="/public/vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
	<script src="/public/vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
	<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
	<!-- start: CLIP-TWO JAVASCRIPTS -->
	<script src="../student/include/assets/js/main.js"></script>
	<!-- start: JavaScript Event Handlers for this page -->
	<script src="../student/include/assets/js/form-elements.js"></script>
	<script>
		jQuery(document).ready(function() {
			Main.init();
			FormElements.init();
		});

		$('.datepicker').datepicker({
			format: 'yyyy-mm-dd',
			startDate: '-3d'
		});
	</script>
	<script type="text/javascript">
		$('#timepicker1').timepicker();
	</script>
	<!-- Optional JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<!-- end: JavaScript Event Handlers for this page -->
	<!-- end: CLIP-TWO JAVASCRIPTS -->

	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>

</body>

</html>