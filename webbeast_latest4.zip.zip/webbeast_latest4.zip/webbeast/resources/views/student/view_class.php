<?php
session_start();
error_reporting(0);
include("/xampp/htdocs/webbeast/public/include/database-connection.php");
include('/xampp/htdocs/webbeast/public/include/checklogin.php');
check_login();

if (isset($_GET['cid'])) {
	$classid = $_GET['cid'];
	$sql = mysqli_query($conn, "select * from stud where id='" . $_SESSION['id'] . "'");
	while ($row = mysqli_fetch_array($sql)) {
		$name = $row['name'];
		$email = $row['email'];
		$contact = $row['contact'];
		$stuid=$row['id'];
		$status=1;


		$sql = mysqli_query($conn, "INSERT INTO enroll_list(stuid,name,email,contact,class_id,status,admin_status) values('$stuid','$name','$email','$contact','$classid','$status','$status')");
		
		if ($sql) {
			echo "<script>alert('You have successfully enrolled into the class. Thank you.');</script>";
			echo "<script>window.location.href ='check_enrol.php'</script>";
		} else {
			echo "<script>alert('Error! Try Again.');</script>";
		}
	}
}
?>
<?php
if (isset($_GET['file_id']) && $_GET['file_id'] > 0) {
	$qry = $conn->query("SELECT * from `class_list` where id = '{$_GET['file_id']}' and delete_flag = 0 ");
	if ($qry->num_rows > 0) {
		foreach ($qry->fetch_assoc() as $k => $v) {
			$$k = $v;
		}
	} else {
		echo '<script>alert("class ID is not valid."); location.replace("./?page=classes")</script>';
	}
} else {
	echo '<script>alert("class ID is Required."); location.replace("./?page=classes")</script>';
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>User | Timetable</title>
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="/public/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="/public/vendor/fontawesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="/public/vendor/themify-icons/themify-icons.min.css">
	<link href="/public/vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/select2/select2.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
	<link rel="stylesheet" href="../student/include/assets/css/styles.css">
	<link rel="stylesheet" href="../student/include/assets/css/plugins.css">
	<link rel="stylesheet" href="../student/include/assets/css/themes/theme-1.css" id="skin_color" />
	<style>
		body {
			color: black;
		}

		.py-3 {
			background-color: black;
		}

		#class-img {
			max-width: 100%;
			max-height: 35em;
			object-fit: scale-down;
			object-position: center center;
		}
	</style>
</head>

<body>
	<div id="app">
		<?php include('include/sidebar.php'); ?>
		<div class="app-content">

			<?php include('include/header.php'); ?>
			<?php
			$sql = mysqli_query($conn, "SELECT * from stud where id='" . $_SESSION['id'] . "'");
			while ($data = mysqli_fetch_array($sql)) { ?>

				<!-- end: TOP NAVBAR -->
				<div class="main-content">
					<div class="wrap-content container" id="container">
						<!-- start: PAGE TITLE -->
						<section id="page-title">
							<div class="row">
								<div class="col-sm-8">
									<h1 class="mainTitle"><?php echo htmlentities($data['name']);
															?> | ENROLL</h1>
								</div>
								<br>
								<?php include('include/clock.php'); ?>
								<ol class="breadcrumb">
									<li>
										<span><?php echo htmlentities($data['name']);
											} ?></span>
									</li>
									<li class="active">
										<span>ENROLL</span>
									</li>
								</ol>
						</section>
						<!-- end: PAGE TITLE -->
						<!-- start: BASIC EXAMPLE -->
						<div class="container-fluid container-fullw bg-white">
							<div class="row">
								<div class="col-md-12">

									<div class="row margin-top-30">
										<div class="col-lg-8 col-md-12">
											<div class="panel panel-white">
												<div class="panel-heading">
													<h5 class="panel-title">ENROLL</h5>
												</div>
												<div class="panel-body">
													<p style="color:red;"><?php echo htmlentities($_SESSION['msg1']); ?>
														<?php echo htmlentities($_SESSION['msg1'] = ""); ?></p>

													<section class="py-3">
														<div class="container">
															<div class="content py-5 px-3 bg-gradient-primary">
																<h2 class="text-center"><b>Class Details</b></h2>
															</div>
															<div class="row mt-lg-n4 mt-md-n4 justify-content-center">
																<div class="col-lg-10 col-md-10 col-sm-12 col-xs-12">
																	<div class="card rounded-0">
																		<div class="card-body">
																			<div class="container-fluid">
																				<center>
																					<img src="<?= (isset($image_path) ? $image_path : '') ?>" alt="<?= isset($name) ? $name : '' ?>" class="img-thumbnail p-0 border" id="class-img">
																				</center>
																				<dl>
																					<dt class="text-muted">Name</dt>
																					<dd class="pl-4"><?= isset($name) ? $name : "" ?></dd>
																					<dt class="text-muted">Description</dt>
																					<dd class="pl-4"><?= isset($description) ? str_replace(["\n\r", "\n", "\r"], "<br>", htmlspecialchars_decode($description)) : '' ?></dd>
																					<dt class="text-muted">Fee</dt>
																					<dd class="pl-4"><?= isset($fee) ? $fee : "" ?></dd>

																				</dl>
																			</div>
																		</div>
																		<div class="card-footer py-1 text-center">
																			<a class="btn btn-light btn-sm bg-gradient-light border rounded-0 text-dark" href="view_class.php?cid=<?= isset($id) ? $id : '' ?>"><i class="fa fa-pen-alt">Enroll</i>
																				<a class="btn btn-light btn-sm bg-gradient-light border rounded-0 text-dark" href="index2.php"><i class="fa fa-angle-left"></i> Back to List</a>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</section>
												</div>
											</div>
										</div>

									</div>
								</div>

							</div>
						</div>

						<!-- end: BASIC EXAMPLE -->






						<!-- end: SELECT BOXES -->

					</div>
				</div>
		</div>
		<!-- start: FOOTER -->
		<?php include('include/footer.php'); ?>
		<!-- end: FOOTER -->

		<!-- start: SETTINGS -->
		<?php include('include/setting.php'); ?>

		<!-- end: SETTINGS -->
	</div>
	<!-- start: MAIN JAVASCRIPTS -->
	<script src="/public/vendor/jquery/jquery.min.js"></script>
	<script src="/public/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="/public/vendor/modernizr/modernizr.js"></script>
	<script src="/public/vendor/jquery-cookie/jquery.cookie.js"></script>
	<script src="/public/vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
	<script src="/public/vendor/switchery/switchery.min.js"></script>
	<!-- end: MAIN JAVASCRIPTS -->
	<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
	<script src="/public/vendor/maskedinput/jquery.maskedinput.min.js"></script>
	<script src="/public/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
	<script src="/public/vendor/autosize/autosize.min.js"></script>
	<script src="/public/vendor/selectFx/classie.js"></script>
	<script src="/public/vendor/selectFx/selectFx.js"></script>
	<script src="/public/vendor/select2/select2.min.js"></script>
	<script src="/public/vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
	<script src="/public/vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
	<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
	<!-- start: CLIP-TWO JAVASCRIPTS -->
	<script src="../student/include/assets/js/main.js"></script>
	<!-- start: JavaScript Event Handlers for this page -->
	<script src="../student/include/assets/js/form-elements.js"></script>
	<script>
		jQuery(document).ready(function() {
			Main.init();
			FormElements.init();
		});

		$('.datepicker').datepicker({
			format: 'yyyy-mm-dd',
			startDate: '-3d'
		});
	</script>
	<script type="text/javascript">
		$('#timepicker1').timepicker();
	</script>
	<!-- Optional JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<!-- end: JavaScript Event Handlers for this page -->
	<!-- end: CLIP-TWO JAVASCRIPTS -->

	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>

</body>

</html>