<?php
session_start();
error_reporting(0);
include("/xampp/htdocs/webbeast/public/include/database-connection.php");
include('checklogin.php');
check_login();

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <script src="./include/assets/js/jquery.js"></script>
  <script src="./include/assets/js/bootstrap.js"></script>
  <script src="./include/assets/js/myjs.js"></script>
  <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="/public/vendor/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="/public/vendor/fontawesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="/public/vendor/themify-icons/themify-icons.min.css">
  <link href="/public/vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
  <link href="/public/vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
  <link href="/public/vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
  <link href="/public/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" media="screen">
  <link href="/public/vendor/select2/select2.min.css" rel="stylesheet" media="screen">
  <link href="/public/vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
  <link href="/public/vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
  <link rel="stylesheet" href="../student/include/assets/css/styles.css">
  <link rel="stylesheet" href="../student/include/assets/css/plugins.css">
  <link rel="stylesheet" href="../student/include/assets/css/themes/theme-1.css" id="skin_color" />

  <title>Subject Registration Form</title>
</head>

<body class="bg-dark">
  <div id="app">
    <?php include('include/sidebar.php'); ?>
    <div class="app-content">

      <?php include('include/header.php'); ?>
      <?php
      $sql = mysqli_query($conn, "SELECT * from stud where id='" . $_SESSION['id'] . "'");
      while ($data = mysqli_fetch_array($sql)) { ?>

        <!-- end: TOP NAVBAR -->
        <div class="main-content">
          <div class="wrap-content container" id="container">
            <!-- start: PAGE TITLE -->
            <section id="page-title">
              <div class="row">
                <div class="col-sm-8">
                  <h1 class="mainTitle"><?php echo htmlentities($data['name']);
                                        ?> | Book Appointment</h1>
                </div>
                <br>
                <?php include('include/clock.php'); ?>
                <ol class="breadcrumb">
                  <li>
                    <span><?php echo htmlentities($data['name']);
                        } ?></span>
                  </li>
                  <li class="active">
                    <span>Book Appointment</span>
                  </li>
                </ol>
            </section>
            <div class="container-fluid container-fullw bg-white">
              <div class="container-fluid">
                <div class="row">
                  <div class="col">
                    <div class="card mt-5">
                      <div class="card-title ml-5 my-2">
                        <!--Registration Button-->
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#Registration">Enroll Subject Here </button>
                      </div>
                      <div class="card-body">
                        <p id="delete-message" class="text-dark"></p>
                        <div id="table"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!--Registration Modal-->
              <div class="modal" id="Registration">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h3 class="text-dark">Subject Registration Form</h3>
                    </div>
                    <div class="modal-body">
                      <p id="message" class="text-dark"></p>
                      <form>
                        <p> Enter the subject code :
                          <select name="SubjectCod" class="form-control" required="required" id="SubjectCode">
                            <option value="">Select the subject code :</option>
                            <?php $ret = mysqli_query($conn, "select * from subject");
                            while ($row = mysqli_fetch_array($ret)) {
                            ?>
                              <option value="<?php echo htmlentities($row['subject_code']); ?> ">
                                <?php echo htmlentities($row['subject_code']); ?> - <?php echo htmlentities($row['subject']); ?>
                              </option>
                            <?php } ?>


                          </select>
                        </p>

                        <p>
                          <select name="SubjectName" class="form-control" required="required" id="SubjectName">
                            <option value="">Select the subject name :</option>
                            <?php $ret = mysqli_query($conn, "select * from subject");
                            while ($row = mysqli_fetch_array($ret)) {
                            ?>
                              <option value="<?php echo htmlentities($row['subject']); ?> ">
                                <?php echo htmlentities($row['subject']); ?>
                              </option>
                            <?php } ?>


                          </select>
                        </p>
                        <p>
                          Class Mode:
                          <select name="ClassMode" class="form-control" required="required" id="ClassMode">
                            <option value="">Select Study Mode</option>
                            <option value="Online">
                              Online
                            </option>
                            <option value="Physical">
                              Physical (Only if you are staying in Johor)
                            </option>

                          </select>

                        </p>
                        <p>
                          Standard/Form:
                          <select name="Class" class="form-control" required="required" id="Class">
                            <option value="">Select Form/Standard</option>
                            <?php $ret = mysqli_query($conn, "select * from form_std");
                            while ($row = mysqli_fetch_array($ret)) {
                            ?>
                              <option value="<?php echo htmlentities($row['Form_Std']); ?>">
                                <?php echo htmlentities($row['Form_Std']); ?>
                              </option>
                            <?php } ?>
                          </select>
                        </p>
                      </form>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-success" id="btn_register">Register Now</button>
                      <button type="button" class="btn btn-danger" data-dismiss="modal" id="btn_close">Close</button>
                    </div>
                  </div>
                </div>
              </div>




              <!--Delete Modal-->

              <div class="modal" id="delete">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h3 class="text-dark">Drop Subject</h3>
                    </div>
                    <div class="modal-body">
                      <p> Do You Want to Drop the Subject ?</p>
                      <button type="button" class="btn btn-success" id="btn_delete_record">Drop Now</button>
                      <button type="button" class="btn btn-danger" data-dismiss="modal" id="btn_close">Close</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
  </div>
  <!-- start: FOOTER -->
  <?php include('include/footer.php'); ?>
    <!-- end: FOOTER -->

    <!-- start: SETTINGS -->
    <?php include('include/setting.php'); ?>

    <!-- end: SETTINGS -->
  </div>
  <!-- start: MAIN JAVASCRIPTS -->
  <script src="/xampp/htdocs/webbeast/public/vendor/jquery/jquery.min.js"></script>
  <script src="/xampp/htdocs/webbeast/public/vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="/xampp/htdocs/webbeast/public/vendor/modernizr/modernizr.js"></script>
  <script src="/xampp/htdocs/webbeast/public/vendor/jquery-cookie/jquery.cookie.js"></script>
  <script src="/xampp/htdocs/webbeast/public/vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
  <script src="/xampp/htdocs/webbeast/public/vendor/switchery/switchery.min.js"></script>
  <!-- end: MAIN JAVASCRIPTS -->
  <!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
  <script src="/xampp/htdocs/webbeast/public/vendor/maskedinput/jquery.maskedinput.min.js"></script>
  <script src="/xampp/htdocs/webbeast/public/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
  <script src="/xampp/htdocs/webbeast/public/vendor/autosize/autosize.min.js"></script>
  <script src="/xampp/htdocs/webbeast/public/vendor/selectFx/classie.js"></script>
  <script src="/xampp/htdocs/webbeast/public/vendor/selectFx/selectFx.js"></script>
  <script src="/xampp/htdocs/webbeast/public/vendor/select2/select2.min.js"></script>
  <script src="/xampp/htdocs/webbeast/public/vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
  <script src="/xampp/htdocs/webbeast/public/vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
  <!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
  <!-- start: CLIP-TWO JAVASCRIPTS -->
  <script src="include/assets/js/main.js"></script>
  <!-- start: JavaScript Event Handlers for this page -->
  <script src="include/assets/js/form-elements.js"></script>
  <script>
    jQuery(document).ready(function() {
      Main.init();
      FormElements.init();
    });
  </script>
  <!-- end: JavaScript Event Handlers for this page -->
  <!-- end: CLIP-TWO JAVASCRIPTS -->
  <script src="include/assets/js/jquery.js"></script>
  <script src="include/assets/js/bootstrap.js"></script>
  <script src="include/assets/js/myjs.js"></script>
</body>

</html>