<?php
session_start();
//error_reporting(0);
include("/xampp/htdocs/webbeast/public/include/database-connection.php");
include('/xampp/htdocs/webbeast/public/include/checklogin.php');
check_login(); 
if (isset($_GET['file_id'])) {
    $classid = $_GET['file_id'];
if (isset($_POST['submit'])) {
    $stuid= $_SESSION['id'];
    
    $sql1 = mysqli_query($conn, "INSERT INTO enroll_list(stuid) values('$stuid')");
    $sql = mysqli_query($conn, "select * from stud where id='" . $_SESSION['id'] . "'");
    
    while ($row = mysqli_fetch_array($sql)) {
  
        $name = $row['name'];
        $email =$row['email'];
        $contact = $row['contact'];
       
    }
    $sql = mysqli_query($conn, "INSERT INTO enroll_list(name,email,contact,class_id) values('$name','$email','$contact','$classid')");
    
    if ($sql) {
        echo"<script>alert('student id is $stuid');</script>";
        echo "<script>alert('Please check your email for registration status. Thank you.');</script>";
    } else {
        echo "<script>alert('Error! Try Again.');</script>";
    }
}
}

?>

<style>
    .carousel-item>img{
        object-fit:cover !important;
    }
    #carouselExampleControls .carousel-inner{
        height:25em !important;
    }
    #uni_modal .modal-footer{
        display:none
    }
</style>
<div class="container-fluid">
    <form id="enroll-form">
        <input type="hidden" name="id" value="">
        <input type="text" name="class_id" value="<?= isset($_GET['cid']) ? $_GET['cid'] : '' ?>">
        <input type="submit">
    </form>
</div>

