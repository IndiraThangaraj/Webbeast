
<div class="sidebar app-aside" id="sidebar">
	<div class="sidebar-container perfect-scrollbar">

		<nav>

			<!-- start: MAIN NAVIGATION MENU -->
			<?php $sql = mysqli_query($conn, "SELECT * from stud where id='" . $_SESSION['id'] . "'");
			while ($data = mysqli_fetch_array($sql)) { ?>
				<ul class="main-navigation-menu">
					<li>
						<a href="#">
							<div class="item-content">
								<div class="item-pic">
									<img class="profile_image" src="data:image/jpg;charset=utf8;base64,<?php echo base64_encode($data['image']);
																									} ?>">
									<div class="item-name">
										<h4>

										</h4>
									</div>
								</div>
							</div>
						</a>
					</li>

					<li>
						<a href="studash.php">
							<div class="item-content">
								<div class="item-media">
									<i class="fa fa-home"></i>
								</div>
								<div class="item-inner">
									<span class="title"> Dashboard </span>
								</div>
							</div>
						</a>
					</li>
					<li>
						<a href="javascript:void(0)">
							<div class="item-content">
								<div class="item-media">
									<i class="fa fa-book"></i>
								</div>
								<div class="item-inner">
									<span class="title"> Subject </span><i class="fa fa-caret-right"></i>
								</div>
							</div>
						</a>
						<ul class="sub-menu">

							<li>
								<a href="timetable_v.php">
									<span class="title">Timetable</span>
								</a>
							</li>
							<li>
								<a href="index.php">
									<span class="title"> Manage Subject </span>
								</a>
							</li>
							<li>
								<a href="review.php">
									<span class="title"> Review Tutor </span>
								</a>
							</li>
						</ul>
					</li>

					<li>
						<a href="javascript:void(0)">
							<div class="item-content">
								<div class="item-media">
									<i class="fa fa-book"></i>
								</div>
								<div class="item-inner">
									<span class="title"> TutorHub </span><i class="fa fa-caret-right"></i>
								</div>
							</div>
						</a>
						<ul class="sub-menu">

							<li>
								<a href="notes_std.php">
									<span class="title"> Notes Standard 1-6 </span>
								</a>
							</li>
							<li>
								<a href="notes_form.php">
									<span class="title"> Notes Form 1-5 </span>
								</a>
							</li>
							<li>
								<a href="search_std.php">
									<span class="title"> Search Notes (Standard 1-6)</span>
								</a>
							</li>

							<li>
								<a href="search_form.php">
									<span class="title"> Search Notes (Form 1-5) </span>
								</a>
							</li>
						</ul>
					</li>

					<li>
						<a href="javascript:void(0)">
							<div class="item-content">
								<div class="item-media">
									<i class="fa fa-graduation-cap"></i>
								</div>
								<div class="item-inner">
									<span class="title"> Extra Academic </span><i class="fa fa-caret-right"></i>
								</div>
							</div>
						</a>
						<ul class="sub-menu">
							<li>
								<a href="index2.php">
									<span class="title"> Register classes </span>
								</a>
							</li>
							<li>
								<a href="check_enrol.php">
									<span class="title"> Check Registration </span>
								</a>
							</li>

						</ul>
					</li>

					<li>
						<a href="javascript:void(0)">
							<div class="item-content">
								<div class="item-media">
									<i class="fa fa-graduation-cap"></i>
								</div>
								<div class="item-inner">
									<span class="title"> Consultation </span><i class="fa fa-caret-right"></i>
								</div>
							</div>
						</a>
						<ul class="sub-menu">
							<li>
								<a href="consultation.php">
									<span class="title"> Book Appointment </span>
								</a>
							</li>
							<li>
								<a href="appointment_history.php">
									<span class="title"> Check status </span>
								</a>
							</li>

						</ul>
					</li>
					<li>
						<a href="stuedit.php">
							<div class="item-content">
								<div class="item-media">
									<i class="fa fa-cog"></i>
								</div>
								<div class="item-inner">
									<span class="title"> Profile Settings </span>
								</div>
							</div>
						</a>
					</li>


					<li>
						<a href="query.php">
							<div class="item-content">
								<div class="item-media">
									<i class="fa fa-envelope"></i>
								</div>
								<div class="item-inner">
									<span class="title"> Send Query </span>
								</div>
							</div>
						</a>
					</li>



					<li>
						<a href="payment.php">
							<div class="item-content">
								<div class="item-media">
									<i class="fa fa-credit-card"></i>
								</div>
								<div class="item-inner">
									<span class="title"> Payment </span>
								</div>
							</div>
						</a>
					</li>


				</ul>
				<!-- end: CORE FEATURES -->

		</nav>
	</div>
</div>