<?php
session_start();
error_reporting(0);
require_once('/xampp/htdocs/webbeast/public/include/database-connection.php');

// Insert Record Function
function InsertRecord()
{
    global $conn;
    $SubjectCode = $_POST['SubjectCode'];
    $ClassMode = $_POST['ClassMode'];
    $Class = $_POST['Class'];
    $SubjectName = $_POST['SubjectName'];
    $stuID = $_SESSION['id'];

    $query = " insert into subject_record (SubjectCode,SubjectName,ClassMode,Class,stuID) values('$SubjectCode','$SubjectName','$ClassMode', '$Class','$stuID')";
    $result = mysqli_query($conn, $query);

    
    if ($result) {
        echo ' Your Record Has Been Saved in the Database';
    } else {
        echo ' Please Check Your Query ';
    }
}

// Display Data Function
function display_record()
{
    global $conn;
    $value = "";
    $value = '<table class="table table-bordered">
                    <tr>
                        <td> No </td>
                        <td> Subject Code </td>
                        <td> Subject Name </td>
                        <td> Class Mode </td>
                        <td> Primary/ Seconadry </td>
                        <td> Delete </td>
                    </tr>';
    $query = "select * from subject_record ";
    $result = mysqli_query($conn, $query);
    $cnt = 1;

    while ($row = mysqli_fetch_assoc($result)) {
        $value .= ' <tr>
                            <td> ' .  $cnt .  ' </td>
                            <td> ' . $row['SubjectCode'] . ' </td>
                            <td> ' . $row['SubjectName'] . '</td>
                            <td> ' . $row['ClassMode'] . ' </td>
                            <td> ' . $row['Class'] . '</td>
                
                            <td> <button class="btn btn-danger" id="btn_delete" data-id1=' . $row['id'] . '><span class="fa fa-trash"></span></button> </td>
                        </tr>';
                        $cnt = $cnt + 1;
    }
    $value .= '</table>';
    echo json_encode(['status' => 'success', 'html' => $value]);
}

// Get Particular Record
function get_record()
{
    global $conn;
    $SubjectID = $_POST['SubjectID'];
    $query = "select * from subject_record where stuID='" . $_SESSION['id'] . "'";
    $result = mysqli_query($conn, $query);

    while ($row = mysqli_fetch_assoc($result)) {
        $User_data = "";
        $User_data[0] = $row['ID'];
        $User_data[1] = $row['SubjectCode'];
        $User_data[2] = $row['SubjectName'];
        $User_data[3] = $row['ClassMode'];
        $User_data[4] = $row['Class'];
    }
    echo json_encode($User_data);
}



function delete_record()
{
    global $conn;
    $Del_Id = $_POST['Del_ID'];
    $query = "DELETE FROM subject_record where id='$Del_Id' ";
    $result = mysqli_query($conn,$query);

    if ($result)
     {
        echo ' Your Record Has Been Delete ';
    } 
    else
     {
        echo ' Please Check Your Query ';
    }
}
