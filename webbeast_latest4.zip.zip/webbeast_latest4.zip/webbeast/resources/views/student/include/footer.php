<link rel="stylesheet" href="../student/include/assets/css/styles.css">
<link rel="stylesheet" href="../student/include/assets/css/themes/theme-1.css" id="skin_color" />

<footer>
	<div class="footer-inner">
		<div class="pull-left">
			<a href="https://instagram.com/jbsandco_?igshid=Yzg5MTU1MDY="><span class="fa-stack fa-2x"> <i class="fa fa-instagram" aria-hidden="true"></i> </span></a>
			<a href="https://www.facebook.com/profile.php?id=100088784838916&mibextid=LQQJ4d"><span class="fa-stack fa-2x"> <i class="fa fa-facebook" aria-hidden="true"></i> </span></a>
			<a href="https://wa.link/9mevjq"><span class="fa-stack fa-2x"> <i class="fa fa-whatsapp" aria-hidden="true"></i> </span></a>
			&copy; <span class="current-year"></span><span class="text-bold text-uppercase"><i class="fas fa-chevron-square-down    "></i></span>. <span>All rights reserved</span>
		</div>
		<div class="pull-right">
			<span class="go-top"><i class="ti-angle-up"></i></span>
		</div>
	</div>
</footer>