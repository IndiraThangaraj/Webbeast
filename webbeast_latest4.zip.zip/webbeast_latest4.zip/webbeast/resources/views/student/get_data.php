<?php 

    require_once('./include/functions.php');
    require_once('/xampp/htdocs/webbeast/public/include/database-connection.php');
    get_record();

?>