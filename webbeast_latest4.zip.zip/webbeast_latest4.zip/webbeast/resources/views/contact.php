<?php
include("/xampp/htdocs/webbeast/public/include/database-connection.php");
if (isset($_POST['submit'])) {
	$name = $_POST['fullname'];
	$email = $_POST['emailid'];
	$mobileno = $_POST['mobileno'];
	$dscrption = $_POST['description'];
	$query = mysqli_query($conn, "insert into query(fullname,email,contactno,message) value('$name','$email','$mobileno','$dscrption')");
	echo "<script>alert('Your inquiry succesfully submitted');</script>";
	echo "<script>window.location.href ='contact.php'</script>";
}


?>
<!DOCTYPE HTML>
<html>

<head>
	<title>JBS | Contact us</title>
	<link href="/public/css/css/contact2.css" rel="stylesheet" type="text/css" media="all" />
	<link href='http://fonts.googleapis.com/css?family=Ropa+Sans' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="/public/vendor/fontawesome/css/font-awesome.min.css">
</head>

<body>
	<!--start-wrap-->

	<!--start-header-->
	<div class="header">
		<div class="wrap">
			<!--start-logo-->
			<div class="logo">
				<img src="/public/images/jbs.jpg" width="60px" , height="60px">
				<a href="index.html" style="font-size: 30px;">JBS EDUCATION AND CONSULTANCY</a>
			</div>
			<!--end-logo-->
			<!--start-top-nav-->
			<div class="top-nav">
				<ul>
					<li><a href="index.php">Home</a></li>

					<li class="active"><a href="contact.php">Contact</a></li>

				</ul>
			</div>
			<div class="clear"> </div>
			<!--end-top-nav-->
		</div>
		<!--end-header-->
	</div>
	<div class="clear"> </div>
	<div class="wrap">
		<div class="contact">
			<div class="section group">
				<div class="col span_1_of_3">
					<h2> CONTACT US </h2> <br><br>
					<a href="https://instagram.com/jbsandco_?igshid=Yzg5MTU1MDY="><img src="/public/images/ig.png" width="50px" height="50px"> jbsandco_</a> <br><br>
					<a href="https://www.facebook.com/profile.php?id=100088784838916&mibextid=LQQJ4d"><img src="/public/images/fb.png" width="50px" height="50px"> JBS & CO</a><br><br>
					<a href="mailto:jbsmanagementandconsultancy@gmail.com"><img src="/public/images/gmail.png" width="50px" height="50px"> jbsmanagementandconsultancy@gmail.com</a><br><br>
					<a href="https://wa.link/9mevjq"><img src="/public/images/whats.png" width="50px" height="50px"> 011-36776985</a>


				</div>
				<div class="col span_2_of_3">
					<div class="contact-form">

						<form name="contactus" method="post">
							<div>
								<span><label>NAME</label></span>
								<span><input type="text" name="fullname" required="true" value=""></span>
							</div>
							<div>
								<span><label>E-MAIL</label></span>
								<span><input type="email" name="emailid" required="ture" value=""></span>
							</div>
							<div>
								<span><label>MOBILE.NO</label></span>
								<span><input type="text" name="mobileno" required="true" value=""></span>
							</div>
							<div>
								<span><label>Message</label></span>
								<span><textarea name="description" required="true"> </textarea></span>
							</div>
							<div>
								<span><input type="submit" name="submit"></span>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="clear"> </div>
		</div>
		<div class="clear"> </div>
	</div>
	<div class="clear"> </div>
	<div class="footer">
		<div class="wrap">
			<div class="footer-left">
				<ul>
					<li><a href="index.php">Home</a></li>

					<li><a href="contact.php">Contact</a></li>


				</ul>
			</div>

			<div class="clear"> </div>
		</div>
	</div>
	<!--end-wrap-->
</body>

</html>