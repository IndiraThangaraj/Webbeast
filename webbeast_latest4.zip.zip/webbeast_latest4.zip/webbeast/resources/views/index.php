
<!DOCTYPE HTML>
<html>
	<head>
		<title>JBS EDUCATION AND CONSULTATION</title>
		<link href="/public/css/css/styles.css" rel="stylesheet" type="text/css"  media="all" />
		<link href='http://fonts.googleapis.com/css?family=Ropa+Sans' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="/public/css/css/responsiveslides.css">
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
		<script src="/public/assets/js/responsiveslides.min.js"></script>
		  <script>
		    // You can also use "$(window).load(function() {"
			    $(function () {
			
			      // Slideshow 1
			      $("#slider1").responsiveSlides({
			        maxwidth: 1600,
			        speed: 600
			      });
			});
		  </script>
	</head>
	<body>
		<!--start-wrap-->
		
			<!--start-header-->
			<div class="header">
				<div class="wrap">
				<!--start-logo-->
				<div class="logo">
					<img src="/public/images/jbs.jpg" width="60px", height="60px">
					<a href="index.php" style="font-size: 40px;">JBS EDUCATION AND CONSULTATION</a>
				</div>
				<!--end-logo-->
				<!--start-top-nav-->
				<div class="top-nav">
					<ul>
						<li class="active"><a href="index.html">Home</a></li>
						
						<li><a href="contact.php">Contact</a></li>
						<li><a href="/resources/views/tutor/tutorreg.php">Tutor Application</a></li>
                        <li><a href="/resources/views/student/sturegister.php">Student Registration</a></li>
                        <li><a href="trial.php">Trial classes</a></li>
					</ul>					
				</div>
				<div class="clear"> </div>
				<!--end-top-nav-->
			</div>
			<!--end-header-->
		</div>
		<div class="clear"> </div>
			<!--start-image-slider---->
					<div class="image-slider">
						<!-- Slideshow 1 -->
					    <ul class="rslides" id="slider1">
					      <li><img src="/public/images/slide1.jpg" alt=""></li>
					      <li><img src="/public/images/slide2.jpg" alt=""></li>
					      <li><img src="/public/images/slide3.png" alt=""></li>
					    </ul>
						 <!-- Slideshow 2 -->
					</div>
					<!--End-image-slider---->
		    <div class="clear"> </div>
		    <div class="content-grids">
		    	<div class="wrap">
		    	<div class="section group">
								
							
				<div class="listview_1_of_3 images_1_of_3">
					<div class="listimg listimg_1_of_2">
						  <img src="/public/images/stulog.png" width="120px" height="120px">
					</div>
					<div class="text list_1_of_2">
						  <h3>Student</h3>
						  <p>Login</p>
						  <div class="button"><span><a href="/resources/views/student/stulogin.php" >Click Here</a></span></div>
				    </div>
				</div>	

				<div class="listview_1_of_3 images_1_of_3">
					<div class="listimg listimg_1_of_2">
						  <img src="/public/images/tutor.png" width="140px" height="120px">
					</div>
					<div class="text list_1_of_2">
						  <h3>Tutor Login</h3>
						  <P>For tutors</P>
						  <div class="button"><span><a href="/resources/views/tutor/tutorlog.php">Click Here</a></span></div>
					</div>
				</div>


					<div class="listview_1_of_3 images_1_of_3">
					<div class="listimg listimg_1_of_2">
						  <img src="/public/images/signup-image.jpg" width="120px" height="120px">
					</div>
					<div class="text list_1_of_2">
						  <h3>Admin Login</h3>
						  <p>JBS System Admin</p>
						
						  <div class="button"><span><a href="/resources/views/ADMIN/ADSignIn.php">Click Here</a></span></div>
				     </div>
					 
				</div>			
			</div>
		    </div>
		   </div>
		   
		   <div class="wrap">
			<div class="content-box">
				<div class="section group">
				
			 	</div>
			</div>
			</div>
		   <div class="clear"> </div>
		   <div class="footer">
		   	 <div class="wrap">
		   	<div class="footer-left">
		   			<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="contact.php">contact</a></li>
						<li><a href="/resources/views/student/sturegister.php">Student Registration</a></li>
                        <li><a href="/resources/views/tutor/tutorreg.php">Tutor Application</a></li>
                        <li><a href="/resources/views/user/trial.php">Trial Class</a></li>
					</ul>
		   	</div>
		   
		   	<div class="clear"> </div>
		   </div>
		   </div>
		<!--end-wrap-->
	</body>
</html>

