<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FrontendController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
}); */
Route::any('/','App\Http\Controllers\FrontendController@index');
Route::any('stulogin','App\Http\Controllers\FrontendController@stulogin')->name('login');

Route::any('stuforgot','App\Http\Controllers\FrontendController@stuforgot');



Route::any('stupass','App\Http\Controllers\FrontendController@stupass');

Route::any('tutoredit','App\Http\Controllers\FrontendController@tutoredit')->name('tutoredit');
Route::any('tutorforgot','App\Http\Controllers\FrontendController@tutorforgot');
Route::any('sturegister','App\Http\Controllers\FrontendController@sturegister');
Route::any('stuedit','App\Http\Controllers\FrontendController@stuedit');
Route::any('tutorlog','App\Http\Controllers\FrontendController@tutorlog');
Route::any('tutorpass','App\Http\Controllers\FrontendController@tutorpass');
Route::any('tutorreg','App\Http\Controllers\FrontendController@tutorreg');

Route::any('ADSignIn','App\Http\Controllers\FrontendController@ADSignIn');
Route::any('ADforgotpass','App\Http\Controllers\FrontendController@ADforgotpass');
Route::any('ADresetpass','App\Http\Controllers\FrontendController@ADresetpass');
Route::any('ADeditprof','App\Http\Controllers\FrontendController@ADeditprof');

Route::any('SignIn','App\Http\Controllers\FrontendController@SignIn');
Route::any('SignUp','App\Http\Controllers\FrontendController@SignUp');
Route::any('forgotpass','App\Http\Controllers\FrontendController@forgotpass');
Route::any('resetpass','App\Http\Controllers\FrontendController@resetpass');
Route::any('editprof','App\Http\Controllers\FrontendController@editprof');
Route::any('studash','App\Http\Controllers\FrontendController@studash');
Route::any('tutordash','App\Http\Controllers\FrontendController@tutordash');
Route::any('ExtraAcademic','App\Http\Controllers\FrontendController@ExtraAcademic');


