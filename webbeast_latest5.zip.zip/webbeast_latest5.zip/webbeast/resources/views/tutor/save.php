<?php 
    // Move the uploaded pdf file into the pdf folder
    move_uploaded_file($file, "./pdf2/" . $fileName); 
?>