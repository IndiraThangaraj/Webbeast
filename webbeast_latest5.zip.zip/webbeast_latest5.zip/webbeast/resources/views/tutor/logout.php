<?php
session_start();
error_reporting(0);
include('./public/include/database-connection.php');
$_SESSION['login']=="";
date_default_timezone_set('Asia/Kolkata');
$ldate=date( 'd-m-Y h:i:s A', time () );

session_unset();

$_SESSION['errmsg']="You have successfully logout";
?>
<script language="javascript">
document.location="../index.php";

</script>