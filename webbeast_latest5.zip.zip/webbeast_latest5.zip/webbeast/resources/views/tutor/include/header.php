
<?php error_reporting(0); ?>
<header class="navbar navbar-default navbar-static-top">
	<!-- start: NAVBAR HEADER -->
	<div class="navbar-header">
		<a href="#" class="sidebar-mobile-toggler pull-left hidden-md hidden-lg" class="btn btn-navbar sidebar-toggle" data-toggle-class="app-slide-off" data-toggle-target="#app" data-toggle-click-outside="#sidebar">
			<i class="ti-align-justify"></i>
		</a>

		<a class="navbar-brand" href="#">
			<h2 style="padding-top:20%; color:#000 ">JBS</h2>
		</a>

		<a href="#" class="sidebar-toggler pull-right visible-md visible-lg" data-toggle-class="app-sidebar-closed" data-toggle-target="#app">
			<i class="fa fa-bars"></i>
		</a>
		<a class="pull-right menu-toggler visible-xs-block" id="menu-toggler" data-toggle="collapse" href=".navbar-collapse">
			<span class="sr-only">Toggle navigation</span>
			<i class="fa fa-bars"></i>
		</a>
	</div>
	<!-- end: NAVBAR HEADER -->
	<!-- start: NAVBAR COLLAPSE -->
	<div class="navbar-collapse collapse">
		<ul class="nav navbar-left">
			<li><img src="/public/images/jbs.jpg" width="60px" , height="60px"></li>
		</ul>
		<ul class="nav navbar-right">
			<!-- start: MESSAGES DROPDOWN -->
			<?php
			$sql = mysqli_query($conn, "SELECT * from tutor_data where id='" . $_SESSION['id'] . "'");
			while ($data = mysqli_fetch_array($sql)) { ?>

				<li class="dropdown current-user">
					<a href class="dropdown-toggle" data-toggle="dropdown">
						<img style="border-radius: 50%" src="data:image/jpg;charset=utf8;base64,<?php echo base64_encode($data['image']); ?>" width="20px" , height="30px"> <br><span class="font-weight-bold"><span class="name">
							<?php echo htmlentities($data['name']);
						} ?>
							<i class="fa fa-angle-down"></i></i></span>
					</a>
					<ul class="dropdown-menu dropdown-dark">


						<li>
							<a href="tutorpass.php">
								<img src="/public/images/pass.png" width="20px" , height="20px"> Change Password
							</a>
						</li>
						<li>
							<a href="logout.php">
								<img src="/public/images/logout.png" width="20px" , height="20px"> Log Out
							</a>
						</li>
					</ul>
				</li>
				<!-- end: USER OPTIONS DROPDOWN -->
		</ul>
		<!-- start: MENU TOGGLER FOR MOBILE DEVICES -->
		<div class="close-handle visible-xs-block menu-toggler" data-toggle="collapse" href=".navbar-collapse">
			<div class="arrow-left"></div>
			<div class="arrow-right"></div>
		</div>
		<!-- end: MENU TOGGLER FOR MOBILE DEVICES -->
	</div>


	<!-- end: NAVBAR COLLAPSE -->
</header>