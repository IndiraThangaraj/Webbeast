<?php
session_start();
error_reporting(0);
include("/xampp/htdocs/webbeast/public/include/database-connection.php");
include('include/checklogin.php');
check_login();

if (isset($_POST['submit'])) {
  $tutor = $_POST["tutor"];
  $subject = $_POST["subject"];
  $form = $_POST["form_std"];
  $day = $_POST["day"];
  $mode = $_POST["mode"];
  $st = $_POST["StartingTime"];
  $et = $_POST["EndingTime"];
  $sql = mysqli_query($conn, "INSERT INTO teachertimetable(tutor, subject, st, et,form_std,day,mode) VALUES ('$tutor', '$subject', '$st', '$et','$form','$day','$mode')");
  if ($sql) {
    echo "<script>alert('Successfully Added.');</script>";
    echo "<script>window.location.href ='create.php'</script>";
  } else {
    echo "<script>alert('Error! Try Again.');</script>";
    echo "<script>window.location.href ='create.php'</script>";
  }
}
?>


<!Doctype html>
<html lang="en">

<head>
  <title>Admin | Tutor Timetable</title>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="/public/vendor/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="/public/vendor/fontawesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="/public/vendor/themify-icons/themify-icons.min.css">
  <link href="/public/vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
  <link href="/public/vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
  <link href="/public/vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
  <link href="/public/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" media="screen">
  <link href="/public/vendor/select2/select2.min.css" rel="stylesheet" media="screen">
  <link href="/public/vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
  <link href="/public/vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="../ADMIN/include/assets/css/styles.css">
  <link rel="stylesheet" href="../ADMIN/include/assets/css/plugins.css">
  <link rel="stylesheet" href="../ADMIN/include/assets/css/themes/theme-1.css" id="skin_color" />
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>

<body>

  <div id="app">
    <?php include('include/sidebar.php'); ?>
    <div class="app-content">
      <?php include('include/header.php'); ?>
      <!-- end: TOP NAVBAR -->
      <div class="main-content">
        <div class="wrap-content container" id="container">
          <!-- start: PAGE TITLE -->
          <section id="page-title">
            <div class="row">
              <div class="col-sm-8">
                <h1 class="mainTitle">Admin | Tutor Timetable</h1>
              </div>
              <br>
              <?php include('include/clock.php'); ?>
              <ol class="breadcrumb">
                <li>
                  <span>Admin</span>
                </li>
                <li class="active">
                  <span>Tutor Timetable</span>
                </li>
              </ol>
            </div>
          </section>
          <!-- end: PAGE TITLE -->
          <!-- start: BASIC EXAMPLE -->
          <div class="container-fluid container-fullw bg-white">
            <div class="row">
              <div class="col-md-12">
                <div class="container">
                  <div class="jumbotron">
                    <h1 class="display-4">Time Table</h1>
                    <p class="lead">Enter Data</p>
                    <form action="" method="post">
                      <div class="form-group">
                        <label for="formGroupExampleInput">Tutor Name</label>
                        <select name="tutor" class=" form-control required=" required>
                          <option value="">Select Tutor</option>
                          <?php $ret = mysqli_query($conn, "select * from tutor_data");
                          while ($row = mysqli_fetch_array($ret)) {
                          ?>
                            <option value="<?php echo htmlentities($row['name']); ?>">
                              <?php echo htmlentities($row['name']); ?>
                            </option>
                          <?php } ?>

                        </select>
                      </div>
                      <div class="form-group">
                        <label for="formGroupExampleInput2">Subject Name</label>
                        <select name="subject" class=" form-control required=" required>
                          <option value="">Select Subject</option>
                          <?php $ret = mysqli_query($conn, "select * from subject");
                          while ($row = mysqli_fetch_array($ret)) {
                          ?>
                            <option value="<?php echo htmlentities($row['subject']); ?>">
                              <?php echo htmlentities($row['subject']); ?>
                            </option>
                          <?php } ?>

                        </select>
                      </div>

                      <div class="form-group">
                        <label for="formGroupExampleInput2">Subject Name</label>
                        <select name="form_std" class=" form-control required=" required>
                          <option value="">Select Form/Standard</option>
                          <?php $ret = mysqli_query($conn, "select * from form_std");
                          while ($row = mysqli_fetch_array($ret)) {
                          ?>
                            <option value="<?php echo htmlentities($row['Form_Std']); ?>">
                              <?php echo htmlentities($row['Form_Std']); ?>
                            </option>
                          <?php } ?>

                        </select>
                      </div>

                      <div class="form-group">
                        <label for="formGroupExampleInput2">Day</label>
                        <select name="day" class=" form-control required=" required>
                          <option value="">Select Day</option>
                          <option value="Sunday">Sunday</option>
                          <option value="Monday">Monday</option>
                          <option value="Tuesday">Tuesday</option>
                          <option value="Wednesday">Wednesday</option>
                          <option value="Thursday">Thursday</option>
                          <option value="Friday">Friday</option>
                          <option value="Saturday">Saturday</option>
                        </select>
                      </div>

                      <div class="form-group">
                        <label for="formGroupExampleInput2">Day</label>
                        <select name="mode" class=" form-control required=" required>
                          <option value="">Select Teaching mode</option>
                          <option value="Online">Online</option>
                          <option value="Physical">Physical</option>
                        </select>
                      </div>

                      <div class="form-group">
                        <label for="formGroupExampleInput4">Starting Time</label>
                        <input type="time" class="form-control" name="StartingTime" id="formGroupExampleInput4" placeholder="24:00:00" required>
                      </div>
                      <div class="form-group">
                        <label for="formGroupExampleInput5">Ending Time</label>
                        <input type="time" class="form-control" name="EndingTime" id="formGroupExampleInput5" placeholder="24:00:00" required>
                      </div>
                      <input type="submit" name="submit" value="Submit" class="btn btn-primary" />

                    </form>
                  </div>
                </div>
                <!-- Optional JavaScript -->
                <!-- jQuery first, then Popper.js, then Bootstrap JS -->
                <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
                <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- end: BASIC EXAMPLE -->
      <!-- end: SELECT BOXES -->

    </div>
    <!-- start: FOOTER -->
    <?php include('include/footer.php'); ?>
    <!-- end: FOOTER -->

    <!-- start: SETTINGS -->
    <?php include('include/setting.php'); ?>

    <!-- end: SETTINGS -->
  </div>
  <!-- start: MAIN JAVASCRIPTS -->
  <script src="/public/vendor/jquery/jquery.min.js"></script>
  <script src="/public/vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="/public/vendor/modernizr/modernizr.js"></script>
  <script src="/public/vendor/jquery-cookie/jquery.cookie.js"></script>
  <script src="/public/vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
  <script src="/public/vendor/switchery/switchery.min.js"></script>
  <!-- end: MAIN JAVASCRIPTS -->
  <!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
  <script src="/public/vendor/maskedinput/jquery.maskedinput.min.js"></script>
  <script src="/public/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
  <script src="/public/vendor/autosize/autosize.min.js"></script>
  <script src="/public/vendor/selectFx/classie.js"></script>
  <script src="/public/vendor/selectFx/selectFx.js"></script>
  <script src="/public/vendor/select2/select2.min.js"></script>
  <script src="/public/vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
  <script src="/public/vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
  <!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
  <!-- start: CLIP-TWO JAVASCRIPTS -->
  <script src="../ADMIN/include/assets/js/main.js"></script>
  <!-- start: JavaScript Event Handlers for this page -->
  <script src="../ADMIN/include/assets/js/form-elements.js"></script>
  <script>
    jQuery(document).ready(function() {
      Main.init();
      FormElements.init();
    });
  </script>
  <!-- end: JavaScript Event Handlers for this page -->
  <!-- end: CLIP-TWO JAVASCRIPTS -->

</body>

</html>