<?php
session_start();
error_reporting(0);
include("/xampp/htdocs/webbeast/public/include/database-connection.php");
include('/xampp/htdocs/webbeast/public/include/checklogin.php');
check_login();

$did = 1;
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];

    $sql = mysqli_query($conn, "update admin set name='$name', contact='$contact', email='$email' where id='$did'");
    if ($sql) {
        echo "<script>alert('Your Profile updated Successfully');</script>";
    }
}
$status = $statusMsg = '';
if (isset($_POST["upload"])) {
    $status = 'error';
    if (!empty($_FILES["image"]["name"])) {
        // Get file info 
        $fileName = basename($_FILES["image"]["name"]);
        $fileType = pathinfo($fileName, PATHINFO_EXTENSION);

        // Allow certain file formats 
        $allowTypes = array('jpg', 'png', 'jpeg', 'gif');
        if (in_array($fileType, $allowTypes)) {
            $image = $_FILES['image']['tmp_name'];
            $imgContent = addslashes(file_get_contents($image));

            // Insert image content into database 
            $sql2 = mysqli_query($conn, "update admin SET image='$imgContent' where id='$did'");

            if ($sql2) {
                $status = 'success';
                $statusMsg = "File uploaded successfully.";
            } else {
                $statusMsg = "File upload failed, please try again.";
            }
        } else {
            $statusMsg = 'Sorry, only JPG, JPEG, PNG, & GIF files are allowed to upload.';
        }
    } else {
        $statusMsg = 'Please select an image file to upload.';
    }
    // Display status message  
    echo $statusMsg;
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <title>Admin | Edit Profile</title>

    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="/public/vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="/public/vendor/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="/public/vendor/themify-icons/themify-icons.min.css">
    <link href="/public/vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
    <link href="/public/vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
    <link href="/public/vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
    <link href="/public/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" media="screen">
    <link href="/public/vendor/select2/select2.min.css" rel="stylesheet" media="screen">
    <link href="/public/vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
    <link href="/public/vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../ADMIN/include/assets/css/styles.css">
    <link rel="stylesheet" href="../ADMIN/include/assets/css/plugins.css">
    <link rel="stylesheet" href="../ADMIN/include/assets/css/themes/theme-1.css" id="skin_color" />
    <!-- Main css -->
    <link rel="stylesheet" href="../ADMIN/include/assets/css/EditProfile.css">
</head>


<body>
    <div id="app">
        <?php include('include/sidebar.php'); ?>
        <div class="app-content">
            <?php include('include/header.php'); ?>
            <!-- end: TOP NAVBAR -->
            <div class="main-content">
                <div class="wrap-content container" id="container">
                    <!-- start: PAGE TITLE -->
                    <section id="page-title">
                        <div class="row">
                            <div class="col-sm-8">
                                <h1 class="mainTitle">Admin | Edit Profile</h1>
                            </div>
                            <br>
                            <?php include('include/clock.php'); ?>
                            <ol class="breadcrumb">
                                <li>
                                    <span>Admin</span>
                                </li>
                                <li class="active">
                                    <span>Edit Profile</span>
                                </li>
                            </ol>
                        </div>
                    </section>
                    <!-- end: PAGE TITLE -->
                    <!-- start: BASIC EXAMPLE -->
                    <div class="container-fluid container-fullw bg-white">
                        <div class="row">
                            <div class="col-md-12">
                                <?php
                                $sql = mysqli_query($conn, "select * from admin where id='$did'");
                                while ($data = mysqli_fetch_array($sql)) {
                                ?>
                                    <form role="form" name="edit" method="post" enctype="multipart/form-data">
                                        <div class="container rounded bg-white mt-5 mb-5">
                                            <div class="row">
                                                <div class="col-md-3 border-right">
                                                    <div class="d-flex1 flex-column align-items-center text-center p-3 py-5">
                                                        <img class="rounded-circle mt-5" width="150px" src="data:image/jpg;charset=utf8;base64,<?php echo base64_encode($data['image']); ?>">
                                                        <br>
                                                        <span class="font-weight-bold"><?php echo htmlentities($data['name']); ?></span>
                                                    </div>
                                                    <div class="image">
                                                        <label>Select Image File:</label>
                                                        <input type="file" name="image">
                                                        <input type="submit" name="upload" value="Upload">
                                                    </div>
                                                </div>
                                                <div class="col-md-9 border-right">
                                                    <div class="p-3 py-5">
                                                        <div class="d-flex justify-content-between align-items-center mb-3">
                                                            <h4 class="text-right">Admin Profile Settings</h4>
                                                        </div>

                                                        <div class="row mt-2">
                                                            <div class="col-md-6"><label class="labels">Name</label><input type="text" class="form-control" name="name" value="<?php echo htmlentities($data['name']); ?>"></div>
                                                        </div>
                                                        <div class="row mt-3">
                                                            <div class="col-md-12"><label class="labels">Contact Number</label><input type="text" class="form-control" name="contact" value="<?php echo htmlentities($data['contact']); ?>"></div>
                                                            <div class="col-md-12"><label class="labels">Email ID</label><input type="text" class="form-control" name="email" value="<?php echo htmlentities($data['email']); ?>"></div>
                                                        </div>
                                                        <div class="row mt-3">

                                                            <div class="mt-5 text-center">
                                                                <button type="submit" name="submit" id="submit" class="btn btn-primary profile-button">Save Profile</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end: BASIC EXAMPLE -->
            <!-- end: SELECT BOXES -->

        </div>
        <!-- start: FOOTER -->
        <?php include('include/footer.php'); ?>
        <!-- end: FOOTER -->

        <!-- start: SETTINGS -->
        <?php include('include/setting.php'); ?>

        <!-- end: SETTINGS -->
    </div>
    <!-- start: MAIN JAVASCRIPTS -->
    <script src="/public/vendor/jquery/jquery.min.js"></script>
    <script src="/public/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="/public/vendor/modernizr/modernizr.js"></script>
    <script src="/public/vendor/jquery-cookie/jquery.cookie.js"></script>
    <script src="/public/vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script src="/public/vendor/switchery/switchery.min.js"></script>
    <!-- end: MAIN JAVASCRIPTS -->
    <!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
    <script src="/public/vendor/maskedinput/jquery.maskedinput.min.js"></script>
    <script src="/public/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
    <script src="/public/vendor/autosize/autosize.min.js"></script>
    <script src="/public/vendor/selectFx/classie.js"></script>
    <script src="/public/vendor/selectFx/selectFx.js"></script>
    <script src="/public/vendor/select2/select2.min.js"></script>
    <script src="/public/vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
    <script src="/public/vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
    <!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
    <!-- start: CLIP-TWO JAVASCRIPTS -->
    <script src="../ADMIN/include/assets/js/main.js"></script>
    <!-- start: JavaScript Event Handlers for this page -->
    <script src="../ADMIN/include/assets/js/form-elements.js"></script>
    <script>
        jQuery(document).ready(function() {
            Main.init();
            FormElements.init();
        });
    </script>
    <!-- end: JavaScript Event Handlers for this page -->
    <!-- end: CLIP-TWO JAVASCRIPTS -->
</body>

</html>
<script>
    $(document).ready(function() {
        $('#insert').change(function() {
            var image_name = $('#image').val();
            if (image_name == '') {
                alert("Please Select Image");
                return false;
            } else {
                var extension = $('#image').val().split('.').pop().toLowerCase();
                if (jQuery.inArray(extension, ['gif', 'png', 'jpg', 'jpeg']) == -1) {
                    alert('Invalid Image File');
                    $('#image').val('');
                    return false;
                }
            }
        });
    });
</script>