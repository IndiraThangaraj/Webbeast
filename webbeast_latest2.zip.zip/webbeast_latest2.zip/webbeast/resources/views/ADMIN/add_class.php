<?php
session_start();
#error_reporting(0);
include("/xampp/htdocs/webbeast/public/include/database-connection.php");
include('include/checklogin.php');
check_login();

if (isset($_POST['submit'])) {
	$name = $_POST['name'];
	$description = $_POST['description'];
	$fee = $_POST['fee'];
	$status = $_POST['status'];
	//$image_path = $_POST['image_path'];

	if (!empty($_FILES["file"]["name"])) {
		// Get file info 
		$fileName = basename($_FILES["file"]["name"]);
		$fileType = pathinfo($fileName, PATHINFO_EXTENSION);
		$file = $_FILES['file']['tmp_name'];
		// Move the uploaded pdf file into the pdf folder
		move_uploaded_file($file, "./images/" . $fileName);
		// Allow certain file formats 
		$allowTypes = array('jpg', 'png', 'jpeg');
		if (in_array($fileType, $allowTypes)) {
			$sql = mysqli_query($conn, "INSERT INTO class_list (file,name,description,fee,status,image_path) VALUES ('$fileName','$name','$description','$fee','$status','images/')");
			if ($sql) {
				echo "<script>alert('Class added Successfully');</script>";
				echo "<script>window.location.href ='class_index.php'</script>";
			} else {
				echo "<script>alert('File upload failed, please try again.');</script>";
				echo "<script>window.location.href ='add_class.php'</script>";
			}
		} else {
			echo "<script>alert('Sorry, only ZIP, RAR & PDF files are allowed to upload.');</script>";
		}
	} else {
		echo "<script>alert('Please select a image file to upload.');</script>";
		echo "<script>window.location.href ='add_class.php'</script>";
	}
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<title>Admin | Add Class</title>
	<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="/public/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="/public/vendor/fontawesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="/public/vendor/themify-icons/themify-icons.min.css">
	<link href="/public/vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/select2/select2.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="../ADMIN/include/assets/css/styles.css">
	<link rel="stylesheet" href="../ADMIN/include/assets/css/plugins.css">
	<link rel="stylesheet" href="../ADMIN/include/assets/css/themes/theme-1.css" id="skin_color" />
	<style>
		#cimg {
			max-width: 100%;
			max-height: 25em;
			object-fit: scale-down;
			object-position: center center;
		}
		.control-label{
			color: black;
		}
		form{
			color: black;
		}
	</style>
</head>

<body>
	<div id="app">
		<?php include('include/sidebar.php'); ?>
		<div class="app-content">
			<?php include('include/header.php'); ?>
			<!-- end: TOP NAVBAR -->
			<div class="main-content">
				<div class="wrap-content container" id="container">
					<!-- start: PAGE TITLE -->
					<section id="page-title">
						<div class="row">
							<div class="col-sm-8">
								<h1 class="mainTitle">Admin | Add Class</h1>
							</div>
							<br>
							<?php include('include/clock.php'); ?>
							<ol class="breadcrumb">
								<li>
									<span>Admin</span>
								</li>
								<li class="active">
									<span>Add Class</span>
								</li>
							</ol>
						</div>
					</section>
					<!-- end: PAGE TITLE -->
					<!-- start: BASIC EXAMPLE -->
					<div class="content py-5 px-3 bg-gradient-primary">
						<h2><b>New Class Entry</b></h2>
					</div>
					<div class="row mt-lg-n4 mt-md-n4 justify-content-center">
						<div class="col-lg-10 col-md-10 col-sm-12 col-xs-12">
							<div class="card rounded-0">
								<div class="card-body">
									<div class="container-fluid">
										<form role="form" name="addclass" method="post" onSubmit="return valid();" id="class-form" enctype="multipart/form-data">
											<div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12">
												<label for="name" class="control-label">Name</label>
												<input type="text" name="name" id="name" class="form-control form-control-sm rounded-0" required />
											</div>
											<div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
												<label for="description" class="control-label">Description</label>
												<textarea rows="3" name="description" id="description" class="form-control form-control-sm rounded-0" required></textarea>
											</div>
											<div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12">
												<label for="fee" class="control-label">Fee</label>
												<input type="number" step="any" name="fee" id="fee" class="form-control form-control-sm rounded-0 text-right" required />
											</div>
											<div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12">
												<label for="status" class="control-label">Status</label>
												<select name="status" id="status" class="form-control form-control-sm rounded-0" required="required">
													<option value="1">Active</option>
													<option value="0">Inactive</option>
												</select>
											</div>
											<div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12">
												<label for="status" class="control-label">Thumbnail</label>
												<div class="custom-file custom-file-sm">
													<input type="file" name="file" class="custom-file-input rounded-0" id="file" onchange="displayImg(this)">
												</div>
											</div>
											<div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12">
												<img src="<?php echo $path . $pdf;  ?>" alt="" id="cimg" class="img-fluid img-thumbnail">
											</div>
											<div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12">
												<button type="submit" name="submit" id="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save</button>
												<a class="btn btn-light btn-sm bg-gradient-light border btn-flat text-dark" href="class_index.php"><i class="fa fa-times"></i> Cancel</a>
											</div>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- end: BASIC EXAMPLE -->
			<!-- end: SELECT BOXES -->
		</div>
		<!-- start: FOOTER -->
		<?php include('include/footer.php'); ?>
		<!-- end: FOOTER -->

		<!-- start: SETTINGS -->
		<?php include('include/setting.php'); ?>
		<!-- end: SETTINGS -->
	</div>
	<script>
		function displayImg(input) {
			if (input.files && input.files[0]) {
				var reader = new FileReader();
				reader.onload = function(e) {
					$('#cimg').attr('src', e.target.result);
					$(input).siblings('.custom-file-label').html(input.files[0].name)
				}

				reader.readAsDataURL(input.files[0]);
			} else {
				$('#cimg').attr('src', "<?php echo (isset($image_path) ? $image_path : '') ?>");
				$(input).siblings('.custom-file-label').html('Choose file')
			}
		}
		$(document).ready(function() {
			$('#description').summernote({
				height: '20em',
				toolbar: [
					['style', ['style']],
					['font', ['bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript', 'clear']],
					['fontname', ['fontname']],
					['fontsize', ['fontsize']],
					['color', ['color']],
					['para', ['ol', 'ul', 'paragraph', 'height']],
					['table', ['table', 'picture', 'video']],
					['view', ['undo', 'redo', 'fullscreen', 'help']]
				]
			})
		})
	</script>
	<!-- start: MAIN JAVASCRIPTS -->
	<script src="/public/vendor/jquery/jquery.min.js"></script>
	<script src="/public/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="/public/vendor/modernizr/modernizr.js"></script>
	<script src="/public/vendor/jquery-cookie/jquery.cookie.js"></script>
	<script src="/public/vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
	<script src="/public/vendor/switchery/switchery.min.js"></script>
	<!-- end: MAIN JAVASCRIPTS -->
	<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
	<script src="/public/vendor/maskedinput/jquery.maskedinput.min.js"></script>
	<script src="/public/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
	<script src="/public/vendor/autosize/autosize.min.js"></script>
	<script src="/public/vendor/selectFx/classie.js"></script>
	<script src="/public/vendor/selectFx/selectFx.js"></script>
	<script src="/public/vendor/select2/select2.min.js"></script>
	<script src="/public/vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
	<script src="/public/vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
	<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
	<!-- start: CLIP-TWO JAVASCRIPTS -->
    <script src="../ADMIN/include/assets/js/main.js"></script>
    <!-- start: JavaScript Event Handlers for this page -->
    <script src="../ADMIN/include/assets/js/form-elements.js"></script>
	<script>
		jQuery(document).ready(function() {
			Main.init();
			FormElements.init();
		});
	</script>
</body>

</html>