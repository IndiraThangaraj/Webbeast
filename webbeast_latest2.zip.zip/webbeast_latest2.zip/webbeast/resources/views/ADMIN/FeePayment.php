<?php
session_start();
error_reporting(0);
include("/xampp/htdocs/webbeast/public/include/database-connection.php");
include('include/checklogin.php');
check_login();

//updating Admin Remark
if (isset($_POST['update'])) {
    $adminremark = $_POST['AdminRemark'];
    $query = mysqli_query($conn, "update payment set AdminRemark='$adminremark'");
    if ($query) {
        echo "<script>alert('Admin Remark updated successfully.');</script>";
    }
}

if (isset($_GET['file_id'])) {
    $id = $_GET['file_id'];
    // fetch file to download from database
    $sql = "SELECT * FROM payment where id=$id ";
    $result = mysqli_query($conn, $sql);

    $file = mysqli_fetch_assoc($result);
    $filepath = 'pdf2/' . $file['file'];

    if (file_exists($filepath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename=' . basename($filepath));
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize('pdf2/' . $file['file']));
        readfile('pdf2/' . $file['file']);
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Admin | Query Details</title>

    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="/public/vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="/public/vendor/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="/public/vendor/themify-icons/themify-icons.min.css">
    <link href="/public/vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
    <link href="/public/vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
    <link href="/public/vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
    <link href="/public/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" media="screen">
    <link href="/public/vendor/select2/select2.min.css" rel="stylesheet" media="screen">
    <link href="/public/vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
    <link href="/public/vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../ADMIN/include/assets/css/styles.css">
    <link rel="stylesheet" href="../ADMIN/include/assets/css/plugins.css">
    <link rel="stylesheet" href="../ADMIN/include/assets/css/themes/theme-1.css" id="skin_color" />
</head>

<body>
    <div id="app">
        <?php include('include/sidebar.php'); ?>
        <div class="app-content">
            <?php include('include/header.php'); ?>
            <!-- end: TOP NAVBAR -->
            <div class="main-content">
                <div class="wrap-content container" id="container">
                    <!-- start: PAGE TITLE -->
                    <section id="page-title">
                        <div class="row">
                            <div class="col-sm-8">
                                <h1 class="mainTitle">Admin | Payment Details</h1>
                            </div>
                            <br>
                            <?php include('include/clock.php'); ?>
                            <ol class="breadcrumb">
                                <li>
                                    <span>Admin</span>
                                </li>
                                <li class="active">
                                    <span>Manage Payment Details</span>
                                </li>
                            </ol>
                        </div>
                    </section>
                    <!-- end: PAGE TITLE -->
                    <!-- start: BASIC EXAMPLE -->
                    <div class="container-fluid container-fullw bg-white">
                        <div class="row">
                            <div class="col-md-12">
                                <table class="table table-hover" id="sample-table-1">
                                    <tbody>
                                        <?php
                                        $sql = mysqli_query($conn, "SELECT stud.*, payment.* FROM payment JOIN stud ON stud.id = payment.stuID");
                                        $cnt = 1;

                                        while ($row = mysqli_fetch_array($sql)) {
                                        ?>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                            <tr>
                                                <td><?php echo $cnt; ?>.</td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <th>Full Name</th>
                                                <td><?php echo $row['name']; ?></td>
                                            </tr>
                                            <tr>
                                                <th>Email Id</th>
                                                <td><?php echo $row['email']; ?></td>
                                            </tr>
                                            <tr>
                                                <th>Contact Number</th>
                                                <td><?php echo $row['contact']; ?></td>
                                            </tr>
                                            <tr>
                                                <th>Payment Date</th>
                                                <td><?php echo $row['paymentDate']; ?></td>
                                            </tr>
                                            <tr>
                                                <th>Proof</th>
                                                <td>
                                                <img height="200px" width="200px" src="data:image/jpg;charset=utf8;base64,<?php echo base64_encode($row['image']); ?>">
                                                </td>
                                                <!-- <td><a href="sample2.php?file_id=<?php echo $row['id'] ?>"><img src="/public/images/pdf.png" style="width:62px;height:62px;text-align: center"></a></td> -->
                                            </tr>
                                            <?php if ($row['AdminRemark'] == "") { ?>
                                                <form name="payment" method="post">
                                                    <tr>
                                                        <th>Admin Remark</th>
                                                        <td><textarea name="AdminRemark" class="form-control" required="true"></textarea></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                        <td>
                                                            <button type="submit" class="btn btn-primary pull-left" name="update">
                                                                Update <i class="fa fa-arrow-circle-right"></i>
                                                            </button>
                                                        </td>
                                                    </tr>
                                                </form>
                                            <?php } else { ?>
                                                <tr>
                                                    <th>Admin Remark</th>
                                                    <td><?php echo $row['AdminRemark']; ?></td>
                                                </tr>
                                        <?php
                                            $cnt = $cnt + 1;}
                                        } ?>
                                        </br>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end: BASIC EXAMPLE -->
            <!-- end: SELECT BOXES -->

        </div>
        <!-- start: FOOTER -->
        <?php include('include/footer.php'); ?>
        <!-- end: FOOTER -->

        <!-- start: SETTINGS -->
        <?php include('include/setting.php'); ?>

        <!-- end: SETTINGS -->
    </div>
    <!-- start: MAIN JAVASCRIPTS -->
	<script src="/public/vendor/jquery/jquery.min.js"></script>
	<script src="/public/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="/public/vendor/modernizr/modernizr.js"></script>
	<script src="/public/vendor/jquery-cookie/jquery.cookie.js"></script>
	<script src="/public/vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
	<script src="/public/vendor/switchery/switchery.min.js"></script>
	<!-- end: MAIN JAVASCRIPTS -->
	<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
	<script src="/public/vendor/maskedinput/jquery.maskedinput.min.js"></script>
	<script src="/public/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
	<script src="/public/vendor/autosize/autosize.min.js"></script>
	<script src="/public/vendor/selectFx/classie.js"></script>
	<script src="/public/vendor/selectFx/selectFx.js"></script>
	<script src="/public/vendor/select2/select2.min.js"></script>
	<script src="/public/vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
	<script src="/public/vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
	<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
	<!-- start: CLIP-TWO JAVASCRIPTS -->
    <script src="../ADMIN/include/assets/js/main.js"></script>
    <!-- start: JavaScript Event Handlers for this page -->
    <script src="../ADMIN/include/assets/js/form-elements.js"></script>
    <script>
        jQuery(document).ready(function() {
            Main.init();
            FormElements.init();
        });
    </script>
    <!-- end: JavaScript Event Handlers for this page -->
    <!-- end: CLIP-TWO JAVASCRIPTS -->
</body>

</html>