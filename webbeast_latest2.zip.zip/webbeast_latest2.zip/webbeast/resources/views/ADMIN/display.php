<?php
session_start();
error_reporting(0);
include("/xampp/htdocs/webbeast/public/include/database-connection.php");
include('include/checklogin.php');
check_login();

if (isset($_GET['del'])) {
  mysqli_query($conn, "delete from teachertimetable where id = '" . $_GET['id'] . "'");
  $_SESSION['msg'] = "data deleted !!";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>Admin | View Tutor Timetable</title>

  <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
  <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="/public/vendor/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="/public/vendor/fontawesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="/public/vendor/themify-icons/themify-icons.min.css">
  <link href="/public/vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
  <link href="/public/vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
  <link href="/public/vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
  <link href="/public/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" media="screen">
  <link href="/public/vendor/select2/select2.min.css" rel="stylesheet" media="screen">
  <link href="/public/vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
  <link href="/public/vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="../ADMIN/include/assets/css/styles.css">
  <link rel="stylesheet" href="../ADMIN/include/assets/css/plugins.css">
  <link rel="stylesheet" href="../ADMIN/include/assets/css/themes/theme-1.css" id="skin_color" />
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

</head>

<body>
  <div id="app">
    <?php include('include/sidebar.php'); ?>
    <div class="app-content">
      <?php include('include/header.php'); ?>
      <div class="main-content">
        <div class="wrap-content container" id="container">
          <!-- start: PAGE TITLE -->
          <section id="page-title">
            <div class="row">
              <div class="col-sm-8">
                <h1 class="mainTitle">Admin | View Tutor Timetable</h1>
              </div>
              <br>
              <?php include('include/clock.php'); ?>
              <ol class="breadcrumb">
                <li>
                  <span>Admin</span>
                </li>
                <li class="active">
                  <span>View Tutor Timetable</span>
                </li>
              </ol>
            </div>
          </section>
          <!-- end: PAGE TITLE -->
          <!-- start: BASIC EXAMPLE -->
          </br></br>
          <div class="container">
            <div class="jumbotron">
              <h1 class="display-4" align="center">Time Table</h1>
              <table class="table">
                <thead class="thead-dark">
                  <tr>
                    <th scope="col">Teacher Name</th>
                    <th scope="col">Subject Name</th>
                    <th scope="col">Form/Standard</th>
                    <th scope="col">Day</th>
                    <th scope="col">Teaching Mode</th>
                    <th scope="col">Starting Time</th>
                    <th scope="col">Ending Time</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  include("/xampp/htdocs/webbeast/public/include/database-connection.php");
                  $sql = "Select * from teachertimetable";
                  $result = mysqli_query($conn, $sql);
                  if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_array($result)) {
                      echo "<tr>
                      <td>" . $row["tutor"] . "</td>
                      <td>" . $row["subject"] . "</td>
                      <td>" . $row["form_std"] . "</td>
                      <td>" . $row["day"] . "</td>
                      <td>" . $row["mode"] . "</td>
                      <td>" . $row["st"] . "</td>
                      <td>" . $row["et"] . "</td>
                      "
                  ?>
                      <td>
                        <a href="edit-display.php?id=<?php echo $row['id']; ?>" class="btn btn-transparent btn-xs" tooltip-placement="top" tooltip="Edit"><i class="fa fa-pencil"></i></a>
                        <a href="display.php?id=<?php echo $row['id'] ?>&del=delete" onClick="return confirm('Are you sure you want to delete?')" class="btn btn-transparent btn-xs tooltips" tooltip-placement="top" tooltip="Remove"><i class="fa fa-times fa fa-white"></i></a>
                      </td>
                  <?php
                      echo "</tr>";
                    }
                    echo "</table>";
                  }
                  ?>

                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <!-- end: BASIC EXAMPLE -->
      <!-- end: SELECT BOXES -->

    </div>
    <!-- start: FOOTER -->
    <?php include('include/footer.php'); ?>
    <!-- end: FOOTER -->

    <!-- start: SETTINGS -->
    <?php include('include/setting.php'); ?>

    <!-- end: SETTINGS -->
  </div>
  <!-- start: MAIN JAVASCRIPTS -->
  <script src="/public/vendor/jquery/jquery.min.js"></script>
  <script src="/public/vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="/public/vendor/modernizr/modernizr.js"></script>
  <script src="/public/vendor/jquery-cookie/jquery.cookie.js"></script>
  <script src="/public/vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
  <script src="/public/vendor/switchery/switchery.min.js"></script>
  <!-- end: MAIN JAVASCRIPTS -->
  <!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
  <script src="/public/vendor/maskedinput/jquery.maskedinput.min.js"></script>
  <script src="/public/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
  <script src="/public/vendor/autosize/autosize.min.js"></script>
  <script src="/public/vendor/selectFx/classie.js"></script>
  <script src="/public/vendor/selectFx/selectFx.js"></script>
  <script src="/public/vendor/select2/select2.min.js"></script>
  <script src="/public/vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
  <script src="/public/vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
  <!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
  <!-- start: CLIP-TWO JAVASCRIPTS -->
  <script src="../ADMIN/include/assets/js/main.js"></script>
  <!-- start: JavaScript Event Handlers for this page -->
  <script src="../ADMIN/include/assets/js/form-elements.js"></script>
  <script>
    jQuery(document).ready(function() {
      Main.init();
      FormElements.init();
    });
  </script>
  <!-- end: JavaScript Event Handlers for this page -->
  <!-- end: CLIP-TWO JAVASCRIPTS -->
  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>

</html>