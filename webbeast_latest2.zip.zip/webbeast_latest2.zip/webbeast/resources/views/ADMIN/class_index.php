<?php
session_start();
error_reporting(0);
include("/xampp/htdocs/webbeast/public/include/database-connection.php");
include('include/checklogin.php');
check_login();

if (isset($_GET['del'])) {
	mysqli_query($conn, "delete from class_list where id = '" . $_GET['id'] . "'");
	$_SESSION['msg'] = "data deleted !!";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<title>Admin | Extra Academic</title>
	<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="/public/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="/public/vendor/fontawesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="/public/vendor/themify-icons/themify-icons.min.css">
	<link href="/public/vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/select2/select2.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
	<link href="/public/vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="../ADMIN/include/assets/css/styles.css">
	<link rel="stylesheet" href="../ADMIN/include/assets/css/plugins.css">
	<link rel="stylesheet" href="../ADMIN/include/assets/css/themes/theme-1.css" id="skin_color" />

	<style>
		.class-img {
			width: 3em;
			height: 3em;
			object-fit: cover;
			object-position: center center;
		}
		table{
			background-color: white;
			margin-top: 5px;
		}
	</style>
</head>


<body>
	<div id="app">
		<?php include('include/sidebar.php'); ?>
		<div class="app-content">
			<?php include('include/header.php'); ?>
			<!-- end: TOP NAVBAR -->
			<div class="main-content">
				<div class="wrap-content container" id="container">
					<!-- start: PAGE TITLE -->
					<section id="page-title">
						<div class="row">
							<div class="col-sm-8">
								<h1 class="mainTitle">Admin | Extra Academic</h1>
							</div>
							<br>
							<?php include('include/clock.php'); ?>
							<ol class="breadcrumb">
								<li>
									<span>Admin</span>
								</li>
								<li class="active">
									<span>Extra Academic</span>
								</li>
							</ol>
						</div>
					</section>
					<!-- end: PAGE TITLE -->
					<!-- start: BASIC EXAMPLE -->
					<div class="card card-outline rounded-0 card-navy">
						<div class="card-header">
							<h3 class="card-title">List of Extra Academic Classes</h3>
							<div class="card-tools">
								<a href="add_class.php" id="create_new" class="btn btn-flat btn-primary"><span class="fas fa-plus"></span> Create New</a>
							</div>
						</div>
						<div class="card-body">
							<div class="container-fluid">
								<table class="table table-bordered" id="list">
									<colgroup>
										<col width="5%">
										<col width="15%">
										<col width="10%">
										<col width="20%">
										<col width="30%">
										<col width="10%">
										<col width="10%">
									</colgroup>
									<thead>
										<tr>
											<th>#</th>
											<th>Date Created</th>
											<th>Image</th>
											<th>Class</th>
											<th>Description</th>
											<th>Status</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
										<?php
										$i = 1;
										$qry = $conn->query("SELECT * from class_list where delete_flag = 0 order by name asc ");
										while ($row = $qry->fetch_assoc()) {
										?>
											<tr>
												<td class="text-center"><?php echo $i++; ?></td>
												<td><?php echo date("Y-m-d H:i", strtotime($row['date_created'])) ?></td>
												<td class="text-center">
													<?php
													//$sql2 = mysqli_query($conn, "SELECT * from class_list where id = 'id' ");

													$pdf = $row['file'];
													$path = $row['image_path'];
													$name = $row['name'];
													?>
													<img src="<?php echo $path . $pdf; ?>" class="img-thumbnail" width="150px" height="150px">


												</td>
												<td class=""><?php echo $row['name'] ?></td>
												<td class="">
													<p class="mb-0 truncate-1"><?php echo strip_tags(htmlspecialchars_decode($row['description'])) ?></p>
												</td>
												<td class="text-center">
													<?php if ($row['status'] == 1) : ?>
														<span class="badge badge-success px-3 rounded-pill">Active</span>
													<?php else : ?>
														<span class="badge badge-danger px-3 rounded-pill">Inactive</span>
													<?php endif; ?>
												</td>
												<td>
													<div class="visible-md visible-lg hidden-sm hidden-xs" role="menu">
														<a class="btn btn-secondary btn-sm bg-gradient-secondary rounded-0" role="button" href="view_class.php?id=<?php echo $row['id'] ?>"><span class="fa fa-eye"></span> View </a>
														<div class="dropdown-divider"></div>
														<a class="btn btn-primary btn-sm bg-gradient-primary rounded-0" href="manage_class.php?id=<?php echo $row['id'] ?>"><span class="fa fa-edit"></span> Edit</a>
														<div class="dropdown-divider"></div>
														<a class="btn btn-danger btn-sm bg-gradient-danger rounded-0" type="button" href="class_index.php?id=<?php echo $row['id'] ?>&del=delete" onClick="return confirm('Are you sure you want to delete?')"><span class="fa fa-trash"></span> Delete</a>
													</div>
												</td>
											</tr>
										<?php } ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- end: BASIC EXAMPLE -->
			<!-- end: SELECT BOXES -->
		</div>
		<!-- start: FOOTER -->
		<?php include('include/footer.php'); ?>
		<!-- end: FOOTER -->

		<!-- start: SETTINGS -->
		<?php include('include/setting.php'); ?>
		<!-- end: SETTINGS -->
	</div>
	<script>
		$(document).ready(function() {
			$('.delete_data').click(function() {
				_conf("Are you sure to delete this Class permanently?", "delete_class", [$(this).attr('data-id')])
			})
			$('.table').dataTable({
				columnDefs: [{
					orderable: false,
					targets: [2, 6]
				}],
				order: [0, 'asc']
			});
			$('.dataTable td,.dataTable th').addClass('py-1 px-2 align-middle')
		})

		function delete_class($id) {
			start_loader();
			$.ajax({
				url: _base_url_ + "classes/Master.php?f=delete_class",
				method: "POST",
				data: {
					id: $id
				},
				dataType: "json",
				error: err => {
					console.log(err)
					alert_toast("An error occured.", 'error');
					end_loader();
				},
				success: function(resp) {
					if (typeof resp == 'object' && resp.status == 'success') {
						location.reload();
					} else {
						alert_toast("An error occured.", 'error');
						end_loader();
					}
				}
			})
		}
	</script>
	<!-- start: MAIN JAVASCRIPTS -->
	<script src="/public/vendor/jquery/jquery.min.js"></script>
	<script src="/public/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="/public/vendor/modernizr/modernizr.js"></script>
	<script src="/public/vendor/jquery-cookie/jquery.cookie.js"></script>
	<script src="/public/vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
	<script src="/public/vendor/switchery/switchery.min.js"></script>
	<!-- end: MAIN JAVASCRIPTS -->
	<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
	<script src="/public/vendor/maskedinput/jquery.maskedinput.min.js"></script>
	<script src="/public/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
	<script src="/public/vendor/autosize/autosize.min.js"></script>
	<script src="/public/vendor/selectFx/classie.js"></script>
	<script src="/public/vendor/selectFx/selectFx.js"></script>
	<script src="/public/vendor/select2/select2.min.js"></script>
	<script src="/public/vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
	<script src="/public/vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
	<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
	<!-- start: CLIP-TWO JAVASCRIPTS -->
    <script src="../ADMIN/include/assets/js/main.js"></script>
    <!-- start: JavaScript Event Handlers for this page -->
    <script src="../ADMIN/include/assets/js/form-elements.js"></script>
	<script>
		jQuery(document).ready(function() {
			Main.init();
			FormElements.init();
		});
	</script>
</body>

</html>