<?php
session_start();
//error_reporting(0);
include("/xampp/htdocs/webbeast/public/include/database-connection.php");
include('include/checklogin.php');
check_login();

if (isset($_POST['submit'])) {
    $tutor = $_POST['tutor'];
    $subject = $_POST['subject'];
    $form = $_POST['form_std'];
    $day = $_POST['day'];
    $st = $_POST['StartingTime'];
    $et = $_POST['EndingTime'];
    $sql = mysqli_query($conn, "update teachertimetable set tutor='$tutor',subject='$subject',form_std='$form',day='$day',st='$st',et='$et' where id ='" . $_GET['id'] . "'");

    if ($sql) {
        $msg = "Tutor Timetable updated Successfully";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Admin | Edit Tutor Timetable</title>

    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="/public/vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="/public/vendor/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="/public/vendor/themify-icons/themify-icons.min.css">
    <link href="/public/vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
    <link href="/public/vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
    <link href="/public/vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
    <link href="/public/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" media="screen">
    <link href="/public/vendor/select2/select2.min.css" rel="stylesheet" media="screen">
    <link href="/public/vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
    <link href="/public/vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../ADMIN/include/assets/css/styles.css">
    <link rel="stylesheet" href="../ADMIN/include/assets/css/plugins.css">
    <link rel="stylesheet" href="../ADMIN/include/assets/css/themes/theme-1.css" id="skin_color" />

</head>

<body>
    <div id="app">
        <?php include('include/sidebar.php'); ?>
        <div class="app-content">

            <?php include('include/header.php'); ?>
            <!-- start: MENU TOGGLER FOR MOBILE DEVICES -->

            <!-- end: TOP NAVBAR -->
            <div class="main-content">
                <div class="wrap-content container" id="container">
                    <!-- start: PAGE TITLE -->
                    <section id="page-title">
                        <div class="row">
                            <div class="col-sm-8">
                                <h1 class="mainTitle">Admin | Edit Tutor Timetable</h1>
                            </div>
                            <br>
                            <?php include('include/clock.php'); ?>
                            <ol class="breadcrumb">
                                <li>
                                    <span>Admin</span>
                                </li>
                                <li class="active">
                                    <span>Edit Tutor Timeable</span>
                                </li>
                            </ol>
                        </div>
                    </section>
                    <!-- end: PAGE TITLE -->
                    <!-- start: BASIC EXAMPLE -->
                    <div class="container-fluid container-fullw bg-white">
                        <div class="row">
                            <div class="col-md-12">
                                <h5 style="color: green; font-size:18px; ">
                                    <?php if ($msg) {
                                        echo htmlentities($msg);
                                    } ?> </h5>
                                <div class="row margin-top-30">
                                    <div class="col-lg-8 col-md-12">
                                        <div class="panel panel-white">
                                            <div class="panel-heading">
                                                <h5 class="panel-title">Edit Tutor Timetable</h5>
                                            </div>
                                            <div class="panel-body">
                                                <?php $sql = mysqli_query($conn, "Select * from teachertimetable where id='" . $_GET['id'] . "'");
                                                while ($data = mysqli_fetch_array($sql)) {
                                                ?>
                                                    <h4><?php echo htmlentities($data['tutor']); ?>'s Profile</h4>

                                                    <hr />
                                                    <form role="form" name="adddoc" method="post" onSubmit="return valid();">

                                                        <div class="form-group">
                                                            <label for="tutor">
                                                                Tutor Name
                                                            </label>
                                                            <input type="text" name="tutor" class="form-control" value="<?php echo htmlentities($data['tutor']); ?>">
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="subject">
                                                                Tutor Subject
                                                            </label>
                                                            <select name="subject" class=" form-control" required="required">
                                                                <option value="<?php echo htmlentities($data['subject']); ?>"><?php echo htmlentities($data['subject']); ?></option>
                                                                <?php $ret = mysqli_query($conn, "select * from subject");
                                                                while ($row = mysqli_fetch_array($ret)) {
                                                                ?>
                                                                    <option value="<?php echo htmlentities($row['subject']); ?>">
                                                                        <?php echo htmlentities($row['subject']); ?>
                                                                    </option>
                                                                <?php } ?>

                                                            </select>
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="form">
                                                                Tutor Form
                                                            </label>
                                                            <select name="form_std" class=" form-control" required="required">
                                                                <option value="<?php echo htmlentities($data['form_std']); ?>"><?php echo htmlentities($data['form_std']); ?></option>
                                                                <?php $ret = mysqli_query($conn, "select * from form_std");
                                                                while ($row = mysqli_fetch_array($ret)) {
                                                                ?>
                                                                    <option value="<?php echo htmlentities($row['Form_Std']); ?>">
                                                                        <?php echo htmlentities($row['Form_Std']); ?>
                                                                    </option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="day">
                                                                Tutor Day
                                                            </label>
                                                            <select name="day" class=" form-control" required="required">
                                                                <option value="<?php echo htmlentities($data['day']); ?>"><?php echo htmlentities($data['day']); ?></option>
                                                                <option value="Sunday">Sunday</option>
                                                                <option value="Monday">Monday</option>
                                                                <option value="Tuesday">Tuesday</option>
                                                                <option value="Wednesday">Wednesday</option>
                                                                <option value="Thursday">Thursday</option>
                                                                <option value="Friday">Friday</option>
                                                                <option value="Saturday">Saturday</option>
                                                            </select>
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="StartingTime">
                                                                Tutor Starting Time
                                                            </label>
                                                            <input type="time" name="StartingTime" class="form-control" required="required" value="<?php echo htmlentities($data['st']); ?>">
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="EndingTime">
                                                                Tutor Ending Time
                                                            </label>
                                                            <input type="time" name="EndingTime" class="form-control" required="required" value="<?php echo htmlentities($data['et']); ?>">
                                                        </div>

                                                        <button type="submit" name="submit" class="btn btn-o btn-primary">
                                                            Update
                                                        </button>
                                                    </form>
                                                <?php } ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12">
                                            <div class="panel panel-white">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end: BASIC EXAMPLE -->

                    <!-- end: SELECT BOXES -->

                </div>
            </div>
        </div>
        <!-- start: FOOTER -->
        <?php include('include/footer.php'); ?>
        <!-- end: FOOTER -->

        <!-- start: SETTINGS -->
        <?php include('include/setting.php'); ?>

        <!-- end: SETTINGS -->
    </div>
     <!-- start: MAIN JAVASCRIPTS -->
	<script src="/public/vendor/jquery/jquery.min.js"></script>
	<script src="/public/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="/public/vendor/modernizr/modernizr.js"></script>
	<script src="/public/vendor/jquery-cookie/jquery.cookie.js"></script>
	<script src="/public/vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
	<script src="/public/vendor/switchery/switchery.min.js"></script>
	<!-- end: MAIN JAVASCRIPTS -->
	<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
	<script src="/public/vendor/maskedinput/jquery.maskedinput.min.js"></script>
	<script src="/public/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
	<script src="/public/vendor/autosize/autosize.min.js"></script>
	<script src="/public/vendor/selectFx/classie.js"></script>
	<script src="/public/vendor/selectFx/selectFx.js"></script>
	<script src="/public/vendor/select2/select2.min.js"></script>
	<script src="/public/vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
	<script src="/public/vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
	<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
	<!-- start: CLIP-TWO JAVASCRIPTS -->
    <script src="../ADMIN/include/assets/js/main.js"></script>
    <!-- start: JavaScript Event Handlers for this page -->
    <script src="../ADMIN/include/assets/js/form-elements.js"></script>
    <script>
        jQuery(document).ready(function() {
            Main.init();
            FormElements.init();
        });
    </script>
    <!-- end: JavaScript Event Handlers for this page -->
    <!-- end: CLIP-TWO JAVASCRIPTS -->
</body>

</html>