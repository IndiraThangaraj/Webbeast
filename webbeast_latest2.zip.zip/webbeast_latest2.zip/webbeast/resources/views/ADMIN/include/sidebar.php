<?php
error_reporting(0);
$did = 1;

$sql = mysqli_query($conn, "select * from admin where id='$did'");
while ($data = mysqli_fetch_array($sql)) {

?>
	<div class="sidebar app-aside" id="sidebar">
		<div class="sidebar-container perfect-scrollbar">
			<nav>
				<!-- start: MAIN NAVIGATION MENU -->
				<ul class="main-navigation-menu">
					<li>
						<a href="#">
							<div class="item-content">
								<div class="item-pic">
									<img src="data:image/jpg;charset=utf8;base64,<?php echo base64_encode($data['image']); ?>" width="200px" , height="180px" class="profile_image">
									<div class="item-name">
										<h4>
											<!--<?php
												//$query = mysqli_query($conn, "select name from admin where id='" . $_SESSION['id'] . "'");
												//while ($row = mysqli_fetch_array($query)) 
												//{
												//echo $row['name'];
												//} 
												?>-->
										</h4>
									</div>
								</div>
							</div>
						</a>
					</li>

					<li>
						<a href="ADdashboard.php">
							<div class="item-content">
								<div class="item-media">
									<i class="fa fa-home"></i>
								</div>
								<div class="item-inner">
									<span class="title"> Dashboard </span>
								</div>
							</div>
						</a>
					</li>
					<li>
						<a href="javascript:void(0)">
							<div class="item-content">
								<div class="item-media">
									<i class="fa fa-user-circle"></i>
								</div>
								<div class="item-inner">
									<span class="title"> Tutors </span><i class="fa fa-caret-right"></i>
								</div>
							</div>
						</a>
						<ul class="sub-menu">
							<li>
								<div class="item-media">
									<a href="add-tutor.php">
										<div class="item-content">
											<div class="item-inner">
												<i class="fa fa-plus-circle"></i>
												<span class="title"> Add Tutors</span>
											</div>
										</div>
									</a>
								</div>
							</li>
							<li>
								<div class="item-media">
									<a href="manage-tutor.php">
										<div class="item-content">
											<div class="item-inner">
												<i class="fa fa-user-md"></i>
												<span class="title"> Manage Tutors </span>
											</div>
										</div>
									</a>
								</div>
							</li>
							<li>
								<div class="item-media">
									<a href="application-history.php">
										<div class="item-content">
											<div class="item-inner">
												<i class="fa fa-history"></i>
												<span class="title"> Tutor Application History </span>
											</div>
										</div>
									</a>
								</div>
							</li>
							<li>
								<div class="item-media">
									<a href="subject_status.php">
										<div class="item-content">
											<div class="item-inner">
												<i class="fa fa-book"></i>
												<span class="title"> Tutor Subject Approval </span>
											</div>
										</div>
									</a>
								</div>
							</li>
						</ul>
					</li>

					<li>
						<a href="javascript:void(0)">
							<div class="item-content">
								<div class="item-media">
									<i class="fa fa-user-circle-o"></i>
								</div>
								<div class="item-inner">
									<span class="title"> Students </span><i class="fa fa-caret-right"></i>
								</div>
							</div>
						</a>
						<ul class="sub-menu">
							<li>
								<div class="item-media">
									<a href="manage-student.php">
										<div class="item-content">
											<div class="item-inner">
												<i class="fa fa-user-md"></i>
												<span class="title"> Manage Students </span>
											</div>
										</div>
									</a>
								</div>
							</li>
							<li>
								<div class="item-media">
									<a href="ADtrialclass.php">
										<div class="item-content">
											<div class="item-inner">
												<i class="fa fa-video-camera"></i>
												<span class="title"> Trial Class </span>
											</div>
										</div>
									</a>
								</div>
							</li>
						</ul>
					</li>
					<li>
						<a href="javascript:void(0)">
							<div class="item-content">
								<div class="item-media">
									<i class="fa fa-files-o"></i>
								</div>
								<div class="item-inner">
									<span class="title"> TutorHub </span><i class="fa fa-caret-right"></i>
								</div>
							</div>
						</a>
						<ul class="sub-menu">
							<li>
								<div class="item-media">
									<a href="TutorHubStd.php">
										<div class="item-content">
											<div class="item-inner">
												<i class="fa fa-plus-circle"></i>
												<span class="title"> TutorHub STD</span>
											</div>
										</div>
									</a>
								</div>
							</li>
							<li>
								<div class="item-media">
									<a href="TutorHubForm.php">
										<div class="item-content">
											<div class="item-inner">
												<i class="fa fa-user-md"></i>
												<span class="title"> TutorHub FORM </span>
											</div>
										</div>
									</a>
								</div>
							</li>
							<li>
								<div class="item-media">
									<a href="tutorhubSearch.php">
										<div class="item-content">
											<div class="item-inner">
												<i class="fa fa-search"></i>
												<span class="title"> TutorHub Search </span>
											</div>
										</div>
									</a>
								</div>
							</li>
						</ul>
					</li>

					<li>
						<a href="student-search.php">
							<div class="item-content">
								<div class="item-media">
									<i class="fa fa-search"></i>
								</div>
								<div class="item-inner">
									<span class="title"> Student Search </span>
								</div>
							</div>
						</a>
					</li>

					<li>
						<a href="javascript:void(0)">
							<div class="item-content">
								<div class="item-media">
									<i class="fa fa-files-o"></i>
								</div>
								<div class="item-inner">
									<span class="title"> Timetable </span><i class="fa fa-caret-right"></i>
								</div>
							</div>
						</a>
						<ul class="sub-menu">
							<li>
								<div class="item-media">
									<a href="create.php">
										<div class="item-content">
											<div class="item-inner">
												<i class="fa fa-plus-circle"></i>
												<span class="title">Create Tutor Timetable </span>
											</div>
										</div>
									</a>
								</div>
							</li>
							<li>
								<div class="item-media">
									<a href="display.php">
										<div class="item-content">
											<div class="item-inner">
												<i class="fa fa-table"></i>
												<span class="title">View Tutor Timetable </span>
											</div>
										</div>
									</a>
								</div>
							</li>
						</ul>
					</li>

					<li>
						<a href="consultation.php">
							<div class="item-content">
								<div class="item-media">
									<i class="fa fa-users"></i>
								</div>
								<div class="item-inner">
									<span class="title"> Consultation Appointment </span>
								</div>
							</div>
						</a>
					</li>

					<li>
						<a href="javascript:void(0)">
							<div class="item-content">
								<div class="item-media">
									<i class="fa fa-file"></i>
								</div>
								<div class="item-inner">
									<span class="title"> Query </span><i class="fa fa-caret-right"></i>
								</div>
							</div>
						</a>
						<ul class="sub-menu">

							<li>
								<div class="item-media">
									<a href="read-query.php">
										<div class="item-content">
											<div class="item-inner">
												<i class="fa fa-file-text"></i>
												<span class="title"> Read Query </span>
											</div>
										</div>
									</a>
								</div>

							</li>
							<li>
								<div class="item-media">
									<a href="unread-queries.php">
										<div class="item-content">
											<div class="item-inner">
												<i class="fa fa-file-text-o"></i>
												<span class="title"> Unread Query </span>
											</div>
										</div>
									</a>
								</div>
							</li>
						</ul>
					</li>

					<li>
						<a href="FeePayment.php">
							<div class="item-content">
								<div class="item-media">
									<i class="fa fa-table"></i>
								</div>
								<div class="item-inner">
									<span class="title"> Payment </span>
								</div>
							</div>
						</a>
					</li>


					<li>
						<a href="javascript:void(0)">
							<div class="item-content">
								<div class="item-media">
									<i class="fa fa-file"></i>
								</div>
								<div class="item-inner">
									<span class="title"> Tutor Review </span><i class="fa fa-caret-right"></i>
								</div>
							</div>
						</a>
						<ul class="sub-menu">
							<li>

								<a href="read-review.php">
									<div class="item-content">
										<div class="item-media">
											<i class="fa fa-file-text"></i>
										</div>
										<div class="item-inner"><span class="title"> Read Review </span>
										</div>
									</div>
								</a>
							</li>
							<li>

								<a href="unread-review.php">
									<div class="item-content">
										<div class="item-media">
											<i class="fa fa-file-text-o"></i>
										</div>
										<div class="item-inner"><span class="title"> Unread Review </span>
										</div>
									</div>
								</a>

							</li>
						</ul>
					</li>
				</ul>
				<!-- end: CORE FEATURES -->

			</nav>
		</div>
	</div>
<?php } ?>